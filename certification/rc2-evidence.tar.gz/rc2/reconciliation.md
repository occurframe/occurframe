# Phase II / RC2 Reconciliation

Phase II RC1 remains historical evidence. This reconciliation does not rewrite RC1 outcomes, alter RC2 expectations, infer correctness from majority behavior, or use the Phase II `157/184` headline as an acceptance target.

- Comparable protocol-v2 cells: 4232
- Observed differences classified: 137
- Legacy ambiguous-error inventory: 814
- Builds not comparable because provenance prevented reproduction: ruby.fugit, ruby.ice_cube

## Reconciliation categories

| Category | Count |
|---|---:|
| `adapter_correction` | 35 |
| `exact_match` | 1192 |
| `fresh_engine_behavior_difference` | 102 |
| `legacy_ambiguous_error` | 814 |
| `protocol_refinement` | 2133 |
| `runtime_environment_change` | 0 |
| `tzdb_provenance_change` | 0 |
| `unresolved_difference` | 0 |

## Unresolved differences

None.

The machine-readable reconciliation retains every classified cell, including all RC1 generic `error` cells as `legacy_ambiguous_error` unless concrete cell-specific evidence exists.
