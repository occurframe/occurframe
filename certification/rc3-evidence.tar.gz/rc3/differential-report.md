# RC2 Differential Certification

This report is a derived view of protocol-v3 observations. The RC3 corpus remains normative authority; this report neither changes expectations nor ranks engines.

## Certification identity and coverage

- Certification: `occurframe-rc3-authority-boundary-certification`
- Certification profile: `rc3.1`
- Tooling source revision: `a8ec520b9fe75a7c5ac4df46a3aec32266c907b5` (Some(AttestedInput))
- Corpus: `1.0.0-rc3` at `cd6569c9f57c9eb8f087f1a18c08f23baa747bde` (Some(GitCheckout)), canonical digest `c0a9cf0587c02ce5022cbb94d060e14d5b9d6f99c3210e512965f35062c4dfe0`
- Runner protocol: `3.0`
- Canonical platform: `Ubuntu 24.04 x86_64`
- Actual observed environment: `environment.json` (the platform label alone does not pin runtimes or TZDB)
- Configured builds: 25
- Reproducible measured builds: 23
- Unreproducible builds: 2
- Vectors: 184
- Observation cells: 4232 / 4232

## Outcome counts

| Category | Count |
|---|---:|
| `accepted` | 35 |
| `engine_error` | 8 |
| `occurrences` | 1333 |
| `rejection` | 756 |
| `timeout` | 1 |
| `unsupported` | 2099 |

## Conformance verdict counts

| Category | Count |
|---|---:|
| `conformant` | 632 |
| `conformant_admissible` | 184 |
| `non_conformant` | 1287 |
| `recorded_unscored` | 29 |
| `timeout` | 1 |
| `unsupported` | 2099 |

## Family coverage

| Category | Count |
|---|---:|
| `cron.anchoring` | 4 |
| `cron.day-fields` | 10 |
| `cron.dow-numbering` | 8 |
| `cron.dst` | 20 |
| `cron.extensions` | 14 |
| `cron.field-count` | 13 |
| `cron.invalid` | 12 |
| `cron.names` | 5 |
| `cron.steps` | 12 |
| `rrule.by` | 32 |
| `rrule.core` | 18 |
| `rrule.dst` | 12 |
| `rrule.sets` | 14 |
| `tzdb.provenance` | 10 |

## Classification coverage

| Category | Count |
|---|---:|
| `AMBIGUOUS_STANDARD` | 21 |
| `DIALECT_DEPENDENT` | 37 |
| `INVALID` | 24 |
| `KNOWN_DIVERGENCE` | 4 |
| `NORMATIVE` | 65 |
| `POLICY_DEPENDENT` | 33 |

## Differential summary

- Semantic-divergence vectors: 163
- Normative-violation vectors: 76
- Documented policy-difference vectors: 26
- Documented dialect-difference vectors: 32
- Named policy answers accepted by the scorer: 6 cells across 1 vectors
- Named dialect answers accepted by the scorer: 0 cells across 0 vectors
- Ambiguous-standard vectors: 21 total; 18 with multiple measured answers
- TZDB-dependent difference vectors: 10
- Timeouts: 1
- Engine errors: 8
- Unsupported cells: 2099
- Runner failures: 0

Semantic divergence counts only occurrences, accepted parses, and deliberate rejections as answers. Unsupported, engine errors, timeouts, and runner failures are execution-pathology categories and are excluded from answer grouping.

No aggregate engine ranking is computed. Any conformance denominator must state how unsupported and unscored cells are handled; this report therefore presents counts rather than an invented overall percentage.

## Measured build provenance

| Build | Runner | Engine | Runtime | Dialect/profile claims | TZDB provenance |
|---|---|---|---|---|---|
| `go.robfig-cron` | `occurframe-go-runner` `3.0.0` | `robfig-cron` `v3.0.1` (`git robfig/cron@bc59245fe10efaed9d51b56900192527ed733435`) | `Go` `go1.24.7` | `dialects=["cron.robfig-v3-standard@1"]; profiles={}` | `{"release":"2026a","release_kind":"exact","source":"system zoneinfo"}` |
| `go.robfig-cron-seconds` | `occurframe-go-runner` `3.0.0` | `robfig-cron[seconds]` `v3.0.1` (`git robfig/cron@bc59245fe10efaed9d51b56900192527ed733435`) | `Go` `go1.24.7` | `dialects=["cron.robfig-v3-seconds@1"]; profiles={}` | `{"release":"2026a","release_kind":"exact","source":"system zoneinfo"}` |
| `go.rrule-go` | `occurframe-go-runner` `3.0.0` | `rrule-go` `v1.8.2` (`git teambition/rrule-go@e74d163475cf1ca1fd019752c5c41ea1f472d4c5`) | `Go` `go1.24.7` | `dialects=[]; profiles={}` | `{"release":"2026a","release_kind":"exact","source":"system zoneinfo"}` |
| `javascript.cron-parser` | `occurframe-javascript-runner` `3.0.0` | `cron-parser` `5.10.0` (`git harrisiirak/cron-parser@7b3a0ad748bffd6eaf6af4caac4d83b1fc392378`) | `JavaScript` `1.3.13` | `dialects=[]; profiles={}` | `{"fingerprint":"TZDB-001/002/003:le2026a","max_inclusive":"2026a","release_kind":"bounded","source":"runtime ICU"}` |
| `javascript.cron-parser-strict` | `occurframe-javascript-runner` `3.0.0` | `cron-parser[strict]` `5.10.0` (`git harrisiirak/cron-parser@7b3a0ad748bffd6eaf6af4caac4d83b1fc392378`) | `JavaScript` `1.3.13` | `dialects=[]; profiles={}` | `{"fingerprint":"TZDB-001/002/003:le2026a","max_inclusive":"2026a","release_kind":"bounded","source":"runtime ICU"}` |
| `javascript.croner` | `occurframe-javascript-runner` `3.0.0` | `croner` `10.0.1` (`git Hexagon/croner@713ee7217e3bbb01857559199e312149d2695edb`) | `JavaScript` `1.3.13` | `dialects=["cron.croner-10@1"]; profiles={}` | `{"fingerprint":"TZDB-001/002/003:le2026a","max_inclusive":"2026a","release_kind":"bounded","source":"runtime ICU"}` |
| `javascript.croner-legacyMode-false` | `occurframe-javascript-runner` `3.0.0` | `croner[legacyMode=false]` `10.0.1` (`git Hexagon/croner@713ee7217e3bbb01857559199e312149d2695edb`) | `JavaScript` `1.3.13` | `dialects=["cron.croner-10@1"]; profiles={}` | `{"fingerprint":"TZDB-001/002/003:le2026a","max_inclusive":"2026a","release_kind":"bounded","source":"runtime ICU"}` |
| `javascript.cronstrue` | `occurframe-javascript-runner` `3.0.0` | `cronstrue` `3.24.0` (`git bradymholt/cRonstrue@b62884a10cc76705c53be65210784108a6d337dd`) | `JavaScript` `1.3.13` | `dialects=[]; profiles={}` | `{"fingerprint":"TZDB-001/002/003:le2026a","max_inclusive":"2026a","release_kind":"bounded","source":"runtime ICU"}` |
| `javascript.rrule-js` | `occurframe-javascript-runner` `3.0.0` | `rrule.js` `2.8.0` (`git jkbrzt/rrule@9f2061febeeb363d03352efe33d30c33073a0242`) | `JavaScript` `1.3.13` | `dialects=[]; profiles={}` | `{"fingerprint":"TZDB-001/002/003:le2026a","max_inclusive":"2026a","release_kind":"bounded","source":"runtime ICU"}` |
| `php.php-cron-expression` | `occurframe-php-runner` `3.0.0` | `php-cron-expression` `3.x@d425a24` (`git dragonmantank/cron-expression@d425a2403c17d7cf911c55a7170f073979a9f382`) | `PHP` `8.4.21` | `dialects=[]; profiles={}` | `{"release":"2026.1","release_kind":"exact","source":"PHP bundled tzdb"}` |
| `php.php-rrule` | `occurframe-php-runner` `3.0.0` | `php-rrule` `2.x@93a083d` (`git rlanvin/php-rrule@93a083db12dcb6f58e4840392a22e158ce96f1ff`) | `PHP` `8.4.21` | `dialects=[]; profiles={}` | `{"release":"2026.1","release_kind":"exact","source":"PHP bundled tzdb"}` |
| `python.aps.system` | `occurframe-python-runner` `3.0.0` | `apscheduler3` `3.11.3` (`git agronholm/apscheduler@4308ec95b94069f5dbdddb6c60fb792dfc8c40a4`) | `Python` `3.11.15` | `dialects=["cron.apscheduler-3@1"]; profiles={"cron.start_inclusivity":"inclusive"}` | `{"release":"2026a","release_kind":"exact","source":"system zoneinfo"}` |
| `python.aps.vendored` | `occurframe-python-runner` `3.0.0` | `apscheduler3` `3.11.3` (`git agronholm/apscheduler@4308ec95b94069f5dbdddb6c60fb792dfc8c40a4`) | `Python` `3.11.15` | `dialects=["cron.apscheduler-3@1"]; profiles={"cron.start_inclusivity":"inclusive"}` | `{"fingerprint":"tzdata-2026.3","release":"2026c","release_kind":"exact","source":"python tzdata package"}` |
| `python.croniter.system` | `occurframe-python-runner` `3.0.0` | `croniter` `6.3.0.dev0` (`git kiorky/croniter@3dd4d14e971294c03d3fb9be3f5ca03ae1c25310`) | `Python` `3.11.15` | `dialects=["cron.croniter-6-or@1"]; profiles={"cron.start_inclusivity":"exclusive"}` | `{"release":"2026a","release_kind":"exact","source":"system zoneinfo"}` |
| `python.croniter.vendored` | `occurframe-python-runner` `3.0.0` | `croniter` `6.3.0.dev0` (`git kiorky/croniter@3dd4d14e971294c03d3fb9be3f5ca03ae1c25310`) | `Python` `3.11.15` | `dialects=["cron.croniter-6-or@1"]; profiles={"cron.start_inclusivity":"exclusive"}` | `{"fingerprint":"tzdata-2026.3","release":"2026c","release_kind":"exact","source":"python tzdata package"}` |
| `python.croniterAnd.system` | `occurframe-python-runner` `3.0.0` | `croniter[day_or=False]` `6.3.0.dev0` (`git kiorky/croniter@3dd4d14e971294c03d3fb9be3f5ca03ae1c25310`) | `Python` `3.11.15` | `dialects=["cron.croniter-6-and@1"]; profiles={"cron.start_inclusivity":"exclusive"}` | `{"release":"2026a","release_kind":"exact","source":"system zoneinfo"}` |
| `python.croniterAnd.vendored` | `occurframe-python-runner` `3.0.0` | `croniter[day_or=False]` `6.3.0.dev0` (`git kiorky/croniter@3dd4d14e971294c03d3fb9be3f5ca03ae1c25310`) | `Python` `3.11.15` | `dialects=["cron.croniter-6-and@1"]; profiles={"cron.start_inclusivity":"exclusive"}` | `{"fingerprint":"tzdata-2026.3","release":"2026c","release_kind":"exact","source":"python tzdata package"}` |
| `python.cronsim.system` | `occurframe-python-runner` `3.0.0` | `cronsim` `2.7` (`git cuu508/cronsim@fd2e617787e94b15beee27fee6ebe6cbe79a72a2`) | `Python` `3.11.15` | `dialects=[]; profiles={}` | `{"release":"2026a","release_kind":"exact","source":"system zoneinfo"}` |
| `python.cronsim.vendored` | `occurframe-python-runner` `3.0.0` | `cronsim` `2.7` (`git cuu508/cronsim@fd2e617787e94b15beee27fee6ebe6cbe79a72a2`) | `Python` `3.11.15` | `dialects=[]; profiles={}` | `{"fingerprint":"tzdata-2026.3","release":"2026c","release_kind":"exact","source":"python tzdata package"}` |
| `python.dateutil.system` | `occurframe-python-runner` `3.0.0` | `python-dateutil` `2.9.0.post0` (`PyPI python-dateutil==2.9.0.post0`) | `Python` `3.11.15` | `dialects=[]; profiles={}` | `{"release":"2026a","release_kind":"exact","source":"system zoneinfo"}` |
| `python.dateutil.vendored` | `occurframe-python-runner` `3.0.0` | `python-dateutil` `2.9.0.post0` (`PyPI python-dateutil==2.9.0.post0`) | `Python` `3.11.15` | `dialects=[]; profiles={}` | `{"fingerprint":"tzdata-2026.3","release":"2026c","release_kind":"exact","source":"python tzdata package"}` |
| `python.pandas.system` | `occurframe-python-runner` `3.0.0` | `pandas` `3.0.2` (`PyPI pandas==3.0.2`) | `Python` `3.11.15` | `dialects=[]; profiles={}` | `{"release":"2026a","release_kind":"exact","source":"system zoneinfo"}` |
| `python.pandas.vendored` | `occurframe-python-runner` `3.0.0` | `pandas` `3.0.2` (`PyPI pandas==3.0.2`) | `Python` `3.11.15` | `dialects=[]; profiles={}` | `{"fingerprint":"tzdata-2026.3","release":"2026c","release_kind":"exact","source":"python tzdata package"}` |

## Semantic answer groups

### `CRON-ANCH-001` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.start_inclusivity`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:b170e8b18fa6b84cedf82c112207b329ad712b4370e852da3778d89c97fca9bb`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: conformant=2. Matched cases: inclusive. Answer: `{"occurrences":["2026-01-01T12:00:00","2026-01-02T12:00:00","2026-01-03T12:00:00"],"type":"occurrences"}`
- `sha256:c62e99d117190c9286074ad18f5547a9076726753ede3b89913c03bcd36447d9`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=4, non_conformant=7. Matched cases: exclusive. Answer: `{"occurrences":["2026-01-02T12:00:00","2026-01-03T12:00:00","2026-01-04T12:00:00"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`

### `CRON-ANCH-002` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.start_truncation`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:bc4a00d955ba9b6479680c68ebc606205bd7f716eaf6f8ce0458c7bba8dbcc78`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-01-02T12:00:00","2026-01-03T12:00:00"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`

### `CRON-ANCH-003` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.start_truncation`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 4 build(s): go.robfig-cron, php.php-cron-expression, python.aps.system, python.aps.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:11858e8d70c00c5baab653308eb9c55c12773178463c601429a2852553a292d8`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 30 seconds past the minute"],"type":"occurrences"}`
- `sha256:1a2fac4c1727cf428dce94f79971d4e1ad5a82a89368213f6f4eff09347e1c00`: 7 build(s): go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=7. Matched cases: none. Answer: `{"occurrences":["2026-01-01T12:00:30","2026-01-01T12:01:30","2026-01-01T12:02:30"],"type":"occurrences"}`
- `sha256:86370d1c937cd46e809b444a1e0a131f719a3b4380894549e56b313eaf002e6e`: 4 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-01-01T12:30:00","2026-01-01T12:30:01","2026-01-01T12:30:02"],"type":"occurrences"}`

### `CRON-ANCH-004` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:27749d83b657020a40a5aff9d4a57aa5e019c2c197966da64209e7d1cff0e054`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:00","2026-01-08T00:00:00","2026-01-15T00:00:00","2026-01-22T00:00:00","2026-01-29T00:00:00","2026-02-01T00:00:00","2026-02-08T00:00:00","2026-02-15T00:00:00","2026-02-22T00:00:00","2026-03-01T00:00:00"],"type":"occurrences"}`
- `sha256:51e210a9923623526fc2fc89a87e98ea2684c840bbff878c66fd2413f3d1c8c4`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-08T00:00:00","2026-01-15T00:00:00","2026-01-22T00:00:00","2026-01-29T00:00:00","2026-02-01T00:00:00","2026-02-08T00:00:00","2026-02-15T00:00:00","2026-02-22T00:00:00","2026-03-01T00:00:00","2026-03-08T00:00:00"],"type":"occurrences"}`
- `sha256:c572914bd3f294cd91ef76426d8f706a846c2cfade1847af0453e251faa37c94`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, every 7 days in a month"],"type":"occurrences"}`

### `CRON-DAYF-001` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.dom_dow`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:05a580c33890c248cbf458ea3c489e84fb8150d0dcb78c5d06ad1b22f0abcc3a`: 8 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"occurrences":["2026-01-02T12:00:00","2026-01-09T12:00:00","2026-01-13T12:00:00","2026-01-16T12:00:00","2026-01-23T12:00:00","2026-01-30T12:00:00"],"type":"occurrences"}`
- `sha256:92d281b68ca53c41c5b5b1f5243ae136a0f4263ef23b9c656d5e8e9df1ee2657`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, on day 13 of the month, and on Friday"],"type":"occurrences"}`
- `sha256:d0517a1001fce069a72027db3d43bbf811bb41b627e609c213efbf1410c56a86`: 5 build(s): javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=5. Matched cases: none. Answer: `{"occurrences":["2026-02-13T12:00:00","2026-03-13T12:00:00","2026-11-13T12:00:00","2027-08-13T12:00:00","2028-10-13T12:00:00","2029-04-13T12:00:00"],"type":"occurrences"}`

### `CRON-DAYF-002` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.dom_dow`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:4a4d940afbf75d1e9e3d37ac48ee8c31b90f530663a245164ea433e8d8bd0e7e`: 8 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"occurrences":["2026-01-01T04:30:00","2026-01-02T04:30:00","2026-01-09T04:30:00","2026-01-15T04:30:00","2026-01-16T04:30:00","2026-01-23T04:30:00","2026-01-30T04:30:00","2026-02-01T04:30:00"],"type":"occurrences"}`
- `sha256:6c0bdcea7b749474259cbe5465faf7d51e3658c157f00a84e15b2a5e40bf9fc6`: 3 build(s): javascript.croner-legacyMode-false, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-05-01T04:30:00","2026-05-15T04:30:00","2027-01-01T04:30:00","2027-01-15T04:30:00","2027-10-01T04:30:00","2027-10-15T04:30:00","2028-09-01T04:30:00","2028-09-15T04:30:00"],"type":"occurrences"}`
- `sha256:b103253411996a0a70cfabeb2dde823537952fa583f9750420a9597b63b17b58`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 04:30 AM, on day 1 and 15 of the month, and on Friday"],"type":"occurrences"}`
- `sha256:cc039aa6b61cdfe1666aa795bfd51c8b03df0d5f7f69056e6fb041fb44fb2eeb`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-08-01T04:30:00","2026-08-15T04:30:00","2027-05-01T04:30:00","2027-05-15T04:30:00","2028-01-01T04:30:00","2028-01-15T04:30:00","2028-04-01T04:30:00","2028-04-15T04:30:00"],"type":"occurrences"}`

### `CRON-DAYF-003` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.dom_dow`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:61d3e2ceb8e84496ce7f9b8a410915d001c7a066f656d68d9a054505e1c56c68`: 5 build(s): javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=5. Matched cases: none. Answer: `{"occurrences":["2026-01-05T11:00:00","2026-04-01T11:00:00","2026-05-05T11:00:00","2026-06-01T11:00:00","2026-07-01T11:00:00","2026-08-05T11:00:00","2026-09-01T11:00:00","2026-10-05T11:00:00"],"type":"occurrences"}`
- `sha256:9732d71b388abd36b64fb45d2c17e4f6b5986d20cb1a3807977c3f6c5d4e3ab8`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 11:00 AM, on day 1 and 5 of the month, Monday through Wednesday"],"type":"occurrences"}`
- `sha256:c6f0c31020e57dc5809e7dbe613e3c1c2cf7e9049e2c2a6cab6af00a837ad294`: 8 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"occurrences":["2026-01-01T11:00:00","2026-01-05T11:00:00","2026-01-06T11:00:00","2026-01-07T11:00:00","2026-01-12T11:00:00","2026-01-13T11:00:00","2026-01-14T11:00:00","2026-01-19T11:00:00"],"type":"occurrences"}`

### `CRON-DAYF-004` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.dom_dow`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:69a279a3d99c26727131c7b7b011481a863167d80bf61764770e9c6c46d2a073`: 8 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"occurrences":["2026-01-04T00:00:00","2026-01-11T00:00:00","2026-01-18T00:00:00","2026-01-25T00:00:00","2026-02-01T00:00:00","2026-02-08T00:00:00"],"type":"occurrences"}`
- `sha256:8d0028a5f21e568675ace4499ab6635be71409df7109644f7d48df3d7e5cd34b`: 5 build(s): javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=5. Matched cases: none. Answer: `{"occurrences":["2026-02-01T00:00:00","2026-03-01T00:00:00","2026-11-01T00:00:00","2027-08-01T00:00:00","2028-10-01T00:00:00","2029-04-01T00:00:00"],"type":"occurrences"}`
- `sha256:d06f9a10fc53d7b268eaddbf3f2a3ab11bf4c6da140b712fb5452bfa6625af07`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, on day 1 of the month, and on Sunday"],"type":"occurrences"}`

### `CRON-DAYF-005` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.dom_dow`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:813907ac37a166f065e5cefda6d36a43c847dd1bce50e804fee824760336f212`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, between day 29 and 31 of the month, and on Monday"],"type":"occurrences"}`
- `sha256:885a7a538936558723d7e4064c4e89a1cda710665d9fbc56eb1d34f98321cda9`: 8 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"occurrences":["2026-01-05T00:00:00","2026-01-12T00:00:00","2026-01-19T00:00:00","2026-01-26T00:00:00","2026-01-29T00:00:00","2026-01-30T00:00:00","2026-01-31T00:00:00","2026-02-02T00:00:00"],"type":"occurrences"}`
- `sha256:d5ee933238c27a4b41a6698b00a8c3cfacd996e9059c51b9db1aca60b92e9e67`: 5 build(s): javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=5. Matched cases: none. Answer: `{"occurrences":["2026-03-30T00:00:00","2026-06-29T00:00:00","2026-08-31T00:00:00","2026-11-30T00:00:00","2027-03-29T00:00:00","2027-05-31T00:00:00","2027-08-30T00:00:00","2027-11-29T00:00:00"],"type":"occurrences"}`

### `CRON-DAYF-006` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.dom_dow`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:633b03a69cb835a965719474d4ee60f8628566c6e757f20bfeeb24378fb13fa7`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 06:00 AM, between day 1 and 7 of the month, and on Monday"],"type":"occurrences"}`
- `sha256:9eb2d2d8d3d54c0e51d9406d8c7a08201a6f305f30fa0eb47170624409675480`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-06T06:00:00","2026-02-03T06:00:00","2026-03-03T06:00:00","2026-04-07T06:00:00","2026-05-05T06:00:00","2026-06-02T06:00:00","2026-07-07T06:00:00","2026-08-04T06:00:00"],"type":"occurrences"}`
- `sha256:cb7bc20f3c8f7676c504c65df26a31ba1bb0adb173390887eb991624bef0b8d1`: 3 build(s): javascript.croner-legacyMode-false, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-01-05T06:00:00","2026-02-02T06:00:00","2026-03-02T06:00:00","2026-04-06T06:00:00","2026-05-04T06:00:00","2026-06-01T06:00:00","2026-07-06T06:00:00","2026-08-03T06:00:00"],"type":"occurrences"}`
- `sha256:f8feeb166bc1f94485a3f9b905b753d1eebffc00139a246a53cc77872785f909`: 8 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"occurrences":["2026-01-01T06:00:00","2026-01-02T06:00:00","2026-01-03T06:00:00","2026-01-04T06:00:00","2026-01-05T06:00:00","2026-01-06T06:00:00","2026-01-07T06:00:00","2026-01-12T06:00:00"],"type":"occurrences"}`

### `CRON-DAYF-010` — `known implementation divergence`

Classification: `KNOWN_DIVERGENCE`. Registered axes: `cron.dialect`, `cron.dom_dow`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 3 build(s): go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict. Verdicts: conformant_admissible=3. Matched cases: reject. Answer: `{"type":"rejection"}`
- `sha256:2380cbb5def0d6938a3e0b66dfb0a26d0e2dd441e5332a1f6aae4d822de612df`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: conformant_admissible=2. Matched cases: and+monday-zero. Answer: `{"occurrences":["2026-01-07T12:00:00","2026-01-14T12:00:00","2026-01-21T12:00:00","2026-01-28T12:00:00","2026-02-04T12:00:00","2026-02-11T12:00:00"],"type":"occurrences"}`
- `sha256:3f91893ab198a9ae03b0af014b5da9b519084c1cf14e9fb859f0130bcdf63562`: 8 build(s): go.robfig-cron, javascript.croner-legacyMode-false, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant_admissible=8. Matched cases: vixie-artefact. Answer: `{"occurrences":["2026-01-06T12:00:00","2026-01-13T12:00:00","2026-01-20T12:00:00","2026-01-27T12:00:00","2026-02-03T12:00:00","2026-02-10T12:00:00"],"type":"occurrences"}`
- `sha256:6162ec2c52df48c6e7c63e80ff494fa0d20464e98c84a7f63ddc5892fda662d5`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, on day * and 10 of the month, and on Tuesday"],"type":"occurrences"}`
- `sha256:7709a523400c56e3b927b01c11a4a25200ab7d3597c111ebb5010628ae722b88`: 2 build(s): javascript.croner, php.php-cron-expression. Verdicts: conformant_admissible=2. Matched cases: or-any-nonstar. Answer: `{"occurrences":["2026-01-01T12:00:00","2026-01-02T12:00:00","2026-01-03T12:00:00","2026-01-04T12:00:00","2026-01-05T12:00:00","2026-01-06T12:00:00"],"type":"occurrences"}`

### `CRON-DAYF-011` — `known implementation divergence`

Classification: `KNOWN_DIVERGENCE`. Registered axes: `cron.dialect`, `cron.dom_dow`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 3 build(s): go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict. Verdicts: conformant_admissible=3. Matched cases: reject. Answer: `{"type":"rejection"}`
- `sha256:2380cbb5def0d6938a3e0b66dfb0a26d0e2dd441e5332a1f6aae4d822de612df`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: conformant_admissible=2. Matched cases: and+monday-zero. Answer: `{"occurrences":["2026-01-07T12:00:00","2026-01-14T12:00:00","2026-01-21T12:00:00","2026-01-28T12:00:00","2026-02-04T12:00:00","2026-02-11T12:00:00"],"type":"occurrences"}`
- `sha256:3f91893ab198a9ae03b0af014b5da9b519084c1cf14e9fb859f0130bcdf63562`: 6 build(s): go.robfig-cron, javascript.croner-legacyMode-false, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: conformant_admissible=6. Matched cases: or-set-semantics. Answer: `{"occurrences":["2026-01-06T12:00:00","2026-01-13T12:00:00","2026-01-20T12:00:00","2026-01-27T12:00:00","2026-02-03T12:00:00","2026-02-10T12:00:00"],"type":"occurrences"}`
- `sha256:7709a523400c56e3b927b01c11a4a25200ab7d3597c111ebb5010628ae722b88`: 4 build(s): javascript.croner, php.php-cron-expression, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant_admissible=4. Matched cases: vixie-artefact. Answer: `{"occurrences":["2026-01-01T12:00:00","2026-01-02T12:00:00","2026-01-03T12:00:00","2026-01-04T12:00:00","2026-01-05T12:00:00","2026-01-06T12:00:00"],"type":"occurrences"}`
- `sha256:90ca54a7f41df461cc31ad89f4b073ccabf763b77e89d51ed6cad415f199c587`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, on day 10 and * of the month, and on Tuesday"],"type":"occurrences"}`

### `CRON-DAYF-012` — `known implementation divergence`

Classification: `KNOWN_DIVERGENCE`. Registered axes: `cron.dialect`, `cron.dom_dow`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: conformant_admissible=2. Matched cases: reject. Answer: `{"type":"rejection"}`
- `sha256:2380cbb5def0d6938a3e0b66dfb0a26d0e2dd441e5332a1f6aae4d822de612df`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: conformant_admissible=2. Matched cases: and+monday-zero. Answer: `{"occurrences":["2026-01-07T12:00:00","2026-01-14T12:00:00","2026-01-21T12:00:00","2026-01-28T12:00:00","2026-02-04T12:00:00","2026-02-11T12:00:00"],"type":"occurrences"}`
- `sha256:3f91893ab198a9ae03b0af014b5da9b519084c1cf14e9fb859f0130bcdf63562`: 3 build(s): javascript.croner-legacyMode-false, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: conformant_admissible=3. Matched cases: or-set-semantics. Answer: `{"occurrences":["2026-01-06T12:00:00","2026-01-13T12:00:00","2026-01-20T12:00:00","2026-01-27T12:00:00","2026-02-03T12:00:00","2026-02-10T12:00:00"],"type":"occurrences"}`
- `sha256:7709a523400c56e3b927b01c11a4a25200ab7d3597c111ebb5010628ae722b88`: 8 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant_admissible=8. Matched cases: vixie-artefact. Answer: `{"occurrences":["2026-01-01T12:00:00","2026-01-02T12:00:00","2026-01-03T12:00:00","2026-01-04T12:00:00","2026-01-05T12:00:00","2026-01-06T12:00:00"],"type":"occurrences"}`
- `sha256:dd35a147b4a09a7a94d30516767a0ca330bc51665ccdf17d3689347ff9cae471`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, between day 1 and 31 of the month, and on Tuesday"],"type":"occurrences"}`

### `CRON-DAYF-013` — `known implementation divergence`

Classification: `KNOWN_DIVERGENCE`. Registered axes: `cron.dialect`, `cron.dom_dow`, `cron.step_gt_field`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 7 build(s): go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored. Verdicts: conformant_admissible=7. Matched cases: reject-step. Answer: `{"type":"rejection"}`
- `sha256:0f64377049c4d965d3fe1aa65c796831a06022e157f2fd843b30ff06c155a861`: 4 build(s): python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant_admissible=4. Matched cases: vixie-artefact. Answer: `{"occurrences":["2026-01-05T00:00:00","2026-02-02T00:00:00","2026-03-02T00:00:00","2026-04-06T00:00:00","2026-05-04T00:00:00","2026-06-01T00:00:00"],"type":"occurrences"}`
- `sha256:449d0a28b009d2e9a2a025289c4fbd7f3594e629d2d3577a90a8cc3ac98cfe3f`: 4 build(s): go.robfig-cron, php.php-cron-expression, python.croniter.system, python.croniter.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-01-02T00:00:00","2026-01-03T00:00:00","2026-01-04T00:00:00","2026-01-05T00:00:00","2026-01-06T00:00:00","2026-01-07T00:00:00"],"type":"occurrences"}`
- `sha256:9d1b9f6e12a8e6b50b25f1bf5802c29c89a1bc15169de23d4151ae9494505dcb`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, every 100 days in a month and 1 through 7, and on Monday"],"type":"occurrences"}`

### `CRON-DOW-001` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.dow_numbering`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:208b72d5451937ca7c9d63c97b12ca7abf961a11413070eba3b52b9cc7afc798`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-05T12:00:00","2026-01-12T12:00:00","2026-01-19T12:00:00","2026-01-26T12:00:00"],"type":"occurrences"}`
- `sha256:c08d38fb472c44992958fcc64f6e3b9304628f026aff374fdb40e138dd19a60a`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-04T12:00:00","2026-01-11T12:00:00","2026-01-18T12:00:00","2026-01-25T12:00:00"],"type":"occurrences"}`
- `sha256:c3b6b1fa5f9d6ea8f0569c66dd856e9f3d4f8319cb836441fe0ddc4c0c4c44b0`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, only on Sunday"],"type":"occurrences"}`

### `CRON-DOW-002` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.dow_numbering`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 5 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser-strict, python.aps.system, python.aps.vendored. Verdicts: non_conformant=5. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:c08d38fb472c44992958fcc64f6e3b9304628f026aff374fdb40e138dd19a60a`: 10 build(s): javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=10. Matched cases: none. Answer: `{"occurrences":["2026-01-04T12:00:00","2026-01-11T12:00:00","2026-01-18T12:00:00","2026-01-25T12:00:00"],"type":"occurrences"}`
- `sha256:c3b6b1fa5f9d6ea8f0569c66dd856e9f3d4f8319cb836441fe0ddc4c0c4c44b0`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, only on Sunday"],"type":"occurrences"}`

### `CRON-DOW-003` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.dow_numbering`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 5 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser-strict, python.aps.system, python.aps.vendored. Verdicts: non_conformant=5. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:c08d38fb472c44992958fcc64f6e3b9304628f026aff374fdb40e138dd19a60a`: 10 build(s): javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=10. Matched cases: none. Answer: `{"occurrences":["2026-01-04T12:00:00","2026-01-11T12:00:00","2026-01-18T12:00:00","2026-01-25T12:00:00"],"type":"occurrences"}`
- `sha256:f33b717ecb08d645149a40bc18ceb23a7f2d4e0a796c0808f9320dfcc7e68139`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, only on Sunday and Sunday"],"type":"occurrences"}`

### `CRON-DOW-005` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.range_wrap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 10 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=10. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:14eec4b86ca32c55c6e0a1be246c8212d6f68e17651f18c90588035bd1e935be`: 4 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-01-02T12:00:00","2026-01-03T12:00:00","2026-01-04T12:00:00","2026-01-05T12:00:00","2026-01-09T12:00:00","2026-01-10T12:00:00"],"type":"occurrences"}`
- `sha256:f03385a23fe4ad873b1a5db2f101ca6f293f6aefb73b43e62b4dd2974d962148`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, Friday through Monday"],"type":"occurrences"}`

### `CRON-DOW-006` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.range_wrap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 10 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=10. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:14eec4b86ca32c55c6e0a1be246c8212d6f68e17651f18c90588035bd1e935be`: 4 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-01-02T12:00:00","2026-01-03T12:00:00","2026-01-04T12:00:00","2026-01-05T12:00:00","2026-01-09T12:00:00","2026-01-10T12:00:00"],"type":"occurrences"}`
- `sha256:f03385a23fe4ad873b1a5db2f101ca6f293f6aefb73b43e62b4dd2974d962148`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, Friday through Monday"],"type":"occurrences"}`

### `CRON-DOW-007` — `normative violation`

Classification: `NORMATIVE`. Registered axes: `cron.dialect`, `cron.range_wrap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 6 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=6. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:2abde521dceeee914f3b1844ddee9691e8e64b4259e04e6d6cd7e1bd5f1c6f98`: 1 build(s): php.php-cron-expression. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-03T12:00:00","2026-01-10T12:00:00","2026-01-17T12:00:00","2026-01-24T12:00:00","2026-01-31T12:00:00","2026-02-07T12:00:00"],"type":"occurrences"}`
- `sha256:33544ab2b377ce911faf7678e73468ebc3e39da1b501882c5a5fc258a065fc97`: 8 build(s): javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"occurrences":["2026-01-03T12:00:00","2026-01-04T12:00:00","2026-01-10T12:00:00","2026-01-11T12:00:00","2026-01-17T12:00:00","2026-01-18T12:00:00"],"type":"occurrences"}`
- `sha256:e54a281cce669939943bd29327e6b71fb2a5067f367518f2c76a69b342e4d9e1`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, Saturday through Sunday"],"type":"occurrences"}`

### `CRON-DOW-008` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:c08d38fb472c44992958fcc64f6e3b9304628f026aff374fdb40e138dd19a60a`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-01-04T12:00:00","2026-01-11T12:00:00","2026-01-18T12:00:00","2026-01-25T12:00:00"],"type":"occurrences"}`
- `sha256:c3b6b1fa5f9d6ea8f0569c66dd856e9f3d4f8319cb836441fe0ddc4c0c4c44b0`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, only on Sunday"],"type":"occurrences"}`

### `CRON-DOW-009` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:208b72d5451937ca7c9d63c97b12ca7abf961a11413070eba3b52b9cc7afc798`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-01-05T12:00:00","2026-01-12T12:00:00","2026-01-19T12:00:00","2026-01-26T12:00:00"],"type":"occurrences"}`
- `sha256:23ce605f70886f4cf12dd6d62e3ab9023dfbcb372f7fee673aa57cd630319374`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, only on Monday, only in January and December"],"type":"occurrences"}`

### `CRON-DOW-011` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.step_on_named_range`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:53ab36474fd524917f4001b52f6dfe22afa2db3ef3ed28b58b5575d8b49c7c7a`: 10 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=10. Matched cases: none. Answer: `{"occurrences":["2026-01-02T12:00:00","2026-01-05T12:00:00","2026-01-07T12:00:00","2026-01-09T12:00:00","2026-01-12T12:00:00","2026-01-14T12:00:00"],"type":"occurrences"}`
- `sha256:81cbe8f27c562f8a20b8c53e42921de235ae9aae29f65717ef22075c7ec78876`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, every 2 days of the week, Monday through Friday"],"type":"occurrences"}`
- `sha256:858e536c746576447f61c279cad769242f70fde460fcc17b971b362b72d7b716`: 1 build(s): php.php-cron-expression. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-04T12:00:00","2026-01-11T12:00:00","2026-01-18T12:00:00","2026-01-25T12:00:00","2026-02-01T12:00:00","2026-02-08T12:00:00"],"type":"occurrences"}`
- `sha256:e8bcd04ba37afac54da3b1356c3aadee6ff3999c7bb488ab1434f46739a6b899`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-01T12:00:00","2026-01-02T12:00:00","2026-01-05T12:00:00","2026-01-06T12:00:00","2026-01-07T12:00:00","2026-01-08T12:00:00"],"type":"occurrences"}`

### `CRON-DOW-012` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.range_wrap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 10 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=10. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:9a66ae1e5d4cd69226f354956e503fe0c8cd0a507c7bf77c76f55aad6c3ee6b8`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, on day 1 of the month, November through February"],"type":"occurrences"}`
- `sha256:f962f047df78a577f2a136b3a306a76ed8f05f591da44dd1c36760a1a94fc29e`: 4 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-01-01T12:00:00","2026-02-01T12:00:00","2026-11-01T12:00:00","2026-12-01T12:00:00","2027-01-01T12:00:00"],"type":"occurrences"}`

### `CRON-DOW-013` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:482458cfb48dea68487d30e311f9d861aaa9693f76eec83db357d932bb69f050`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-04T12:00:00","2026-01-11T12:00:00","2026-01-18T12:00:00"],"type":"occurrences"}`
- `sha256:5ffb56749192b475edc7fa61b730e52d96d97dcd4ba63a2d0f8e974bc4d3f690`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-05T12:00:00","2026-01-12T12:00:00","2026-01-19T12:00:00"],"type":"occurrences"}`
- `sha256:c3b6b1fa5f9d6ea8f0569c66dd856e9f3d4f8319cb836441fe0ddc4c0c4c44b0`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, only on Sunday"],"type":"occurrences"}`

### `CRON-DST-001` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:0e4d271a19d4f9048283cc32639c7c62aa9c4ed1038f6f99ffafb7ee6548dfe2`: 6 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=6. Matched cases: none. Answer: `{"occurrences":["2026-03-07T02:30:00-05:00|2026-03-07T07:30:00Z","2026-03-08T03:00:00-04:00|2026-03-08T07:00:00Z","2026-03-09T02:30:00-04:00|2026-03-09T06:30:00Z","2026-03-10T02:30:00-04:00|2026-03-10T06:30:00Z"],"type":"occurrences"}`
- `sha256:1788cfe42c6c43e3ad9f89d6dd5301b627d2720d00330a85c92cca0f84d4c267`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 02:30 AM"],"type":"occurrences"}`
- `sha256:61c0fcbff56161afe86c2cea13e44a21794e408690089dc8e06a14def6e92f49`: 4 build(s): javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-03-07T02:30:00-05:00|2026-03-07T07:30:00Z","2026-03-08T03:30:00-04:00|2026-03-08T07:30:00Z","2026-03-09T02:30:00-04:00|2026-03-09T06:30:00Z","2026-03-10T02:30:00-04:00|2026-03-10T06:30:00Z"],"type":"occurrences"}`
- `sha256:756282771090bf2c13c067050621aef6aa4992445870cae214295efa680f3ca6`: 1 build(s): go.robfig-cron. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-03-07T02:30:00-05:00|2026-03-07T07:30:00Z","2026-03-09T02:30:00-04:00|2026-03-09T06:30:00Z","2026-03-10T02:30:00-04:00|2026-03-10T06:30:00Z","2026-03-11T02:30:00-04:00|2026-03-11T06:30:00Z"],"type":"occurrences"}`
- `sha256:8aa6446b1087222b33f156bae662e93aa695ffe2370526641e2029a2b8c345fd`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-07T02:30:00-05:00|2026-03-07T07:30:00Z","2026-03-08T02:30:00-05:00|2026-03-08T07:30:00Z","2026-03-09T02:30:00-04:00|2026-03-09T06:30:00Z","2026-03-10T02:30:00-04:00|2026-03-10T06:30:00Z"],"type":"occurrences"}`

### `CRON-DST-002` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:1fa2cca89264b0c92630c8f6d8ebda6c9424f1b8bd1c78debd244f1abbda1141`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 01:30 AM"],"type":"occurrences"}`
- `sha256:551330456368db651b30d1805b942fb8a9588fbb231b68dc72d0175bb900ff05`: 5 build(s): javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=5. Matched cases: none. Answer: `{"occurrences":["2026-10-30T01:30:00-04:00|2026-10-30T05:30:00Z","2026-10-31T01:30:00-04:00|2026-10-31T05:30:00Z","2026-11-01T01:30:00-04:00|2026-11-01T05:30:00Z","2026-11-02T01:30:00-05:00|2026-11-02T06:30:00Z"],"type":"occurrences"}`
- `sha256:a0312ec4266d126874c94b4dd31a764b3ac842da6d6fb032798a448cdfd9b551`: 8 build(s): go.robfig-cron, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"occurrences":["2026-10-30T01:30:00-04:00|2026-10-30T05:30:00Z","2026-10-31T01:30:00-04:00|2026-10-31T05:30:00Z","2026-11-01T01:30:00-04:00|2026-11-01T05:30:00Z","2026-11-01T01:30:00-05:00|2026-11-01T06:30:00Z"],"type":"occurrences"}`

### `CRON-DST-003` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:3c30b00ba17700061b3482bd36817067d1d23c8690384120374ec2cd7006913e`: 2 build(s): javascript.croner, javascript.croner-legacyMode-false. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-10-02T02:15:00+10:30|2026-10-01T15:45:00Z","2026-10-03T02:15:00+10:30|2026-10-02T15:45:00Z","2026-10-04T02:45:00+11:00|2026-10-03T15:45:00Z","2026-10-05T02:15:00+11:00|2026-10-04T15:15:00Z"],"type":"occurrences"}`
- `sha256:4e15937f45c8bb8aa2c5aaaafb1a62a1c21dba4880088d9dda0705779f0feae8`: 3 build(s): go.robfig-cron, javascript.cron-parser, php.php-cron-expression. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-10-02T02:15:00+10:30|2026-10-01T15:45:00Z","2026-10-03T02:15:00+10:30|2026-10-02T15:45:00Z","2026-10-05T02:15:00+11:00|2026-10-04T15:15:00Z","2026-10-06T02:15:00+11:00|2026-10-05T15:15:00Z"],"type":"occurrences"}`
- `sha256:cc7795c7432598295aa21b9a8b24b89591a82856025e5eede76f62b9bc8ff747`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 02:15 AM"],"type":"occurrences"}`
- `sha256:d2e2d100557aa0183c6a2c00431078560ee06b15f48f53661a9fa8f184cee20f`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-10-02T02:15:00+10:30|2026-10-01T15:45:00Z","2026-10-03T02:15:00+10:30|2026-10-02T15:45:00Z","2026-10-04T02:15:00+10:30|2026-10-03T15:45:00Z","2026-10-05T02:15:00+11:00|2026-10-04T15:15:00Z"],"type":"occurrences"}`
- `sha256:e1f744e606bc4d08b8daba868b84dda26a75925ddaf578063a190fdb26df0c13`: 6 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=6. Matched cases: none. Answer: `{"occurrences":["2026-10-02T02:15:00+10:30|2026-10-01T15:45:00Z","2026-10-03T02:15:00+10:30|2026-10-02T15:45:00Z","2026-10-04T02:30:00+11:00|2026-10-03T15:30:00Z","2026-10-05T02:15:00+11:00|2026-10-04T15:15:00Z"],"type":"occurrences"}`

### `CRON-DST-004` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:96e34e15f8d5072c7bd89757ba362cc930e0612313094d02c7752a1517fe09b4`: 8 build(s): go.robfig-cron, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"occurrences":["2026-04-03T01:45:00+11:00|2026-04-02T14:45:00Z","2026-04-04T01:45:00+11:00|2026-04-03T14:45:00Z","2026-04-05T01:45:00+11:00|2026-04-04T14:45:00Z","2026-04-05T01:45:00+10:30|2026-04-04T15:15:00Z"],"type":"occurrences"}`
- `sha256:a077c629049c6374a385e9da0dc5ec81375c7a5e0695b4e40355e996c1a50e47`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 01:45 AM"],"type":"occurrences"}`
- `sha256:ddc4131920f2dda30f41a9325039cc861f8c8dcc1ed403666a29276321dc2460`: 2 build(s): javascript.croner, javascript.croner-legacyMode-false. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-04-03T01:45:00+11:00|2026-04-02T14:45:00Z","2026-04-04T01:45:00+11:00|2026-04-03T14:45:00Z","2026-04-05T01:45:00+10:30|2026-04-04T15:15:00Z","2026-04-06T01:45:00+10:30|2026-04-05T15:15:00Z"],"type":"occurrences"}`
- `sha256:e2c08cf132cfd780d8d8fb340f2dbb1769c255d3dc3abdcc422fe98c8d309ddb`: 3 build(s): javascript.cron-parser, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-04-03T01:45:00+11:00|2026-04-02T14:45:00Z","2026-04-04T01:45:00+11:00|2026-04-03T14:45:00Z","2026-04-05T01:45:00+11:00|2026-04-04T14:45:00Z","2026-04-06T01:45:00+10:30|2026-04-05T15:15:00Z"],"type":"occurrences"}`

### `CRON-DST-005` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:1fa2cca89264b0c92630c8f6d8ebda6c9424f1b8bd1c78debd244f1abbda1141`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 01:30 AM"],"type":"occurrences"}`
- `sha256:49be21bd89e83e585b0c6b06fe89209e9f1509aff48c00e9c54dcbff24957fb2`: 3 build(s): javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-03-27T01:30:00+00:00|2026-03-27T01:30:00Z","2026-03-28T01:30:00+00:00|2026-03-28T01:30:00Z","2026-03-29T03:30:00+02:00|2026-03-29T01:30:00Z","2026-03-30T01:30:00+02:00|2026-03-29T23:30:00Z"],"type":"occurrences"}`
- `sha256:6d13ad429c0df7f7bbd3e2cf74f65f39cbd0684d1c22ac4d59b0908efac69799`: 2 build(s): go.robfig-cron, php.php-cron-expression. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-27T01:30:00+00:00|2026-03-27T01:30:00Z","2026-03-28T01:30:00+00:00|2026-03-28T01:30:00Z","2026-03-30T01:30:00+02:00|2026-03-29T23:30:00Z","2026-03-31T01:30:00+02:00|2026-03-30T23:30:00Z"],"type":"occurrences"}`
- `sha256:ef133715fbc9215291eebab52aa0c48b68a485c72d4912ce9531fec9794758b0`: 6 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=6. Matched cases: none. Answer: `{"occurrences":["2026-03-27T01:30:00+00:00|2026-03-27T01:30:00Z","2026-03-28T01:30:00+00:00|2026-03-28T01:30:00Z","2026-03-29T03:00:00+02:00|2026-03-29T01:00:00Z","2026-03-30T01:30:00+02:00|2026-03-29T23:30:00Z"],"type":"occurrences"}`
- `sha256:f580d2d55ce96da4f4c5c9f7e4e923c9c8ff8e716987c5edd3571b3e00e570d7`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-27T01:30:00+00:00|2026-03-27T01:30:00Z","2026-03-28T01:30:00+00:00|2026-03-28T01:30:00Z","2026-03-29T01:30:00+00:00|2026-03-29T01:30:00Z","2026-03-30T01:30:00+02:00|2026-03-29T23:30:00Z"],"type":"occurrences"}`

### `CRON-DST-006` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:1fa2cca89264b0c92630c8f6d8ebda6c9424f1b8bd1c78debd244f1abbda1141`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 01:30 AM"],"type":"occurrences"}`
- `sha256:21808f797fa93a6a7b933b9a795f8768307a68fb106415ee58a481984a33f252`: 2 build(s): javascript.croner, javascript.croner-legacyMode-false. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-10-24T01:30:00+02:00|2026-10-23T23:30:00Z","2026-10-25T01:30:00+00:00|2026-10-25T01:30:00Z","2026-10-26T01:30:00+00:00|2026-10-26T01:30:00Z","2026-10-27T01:30:00+00:00|2026-10-27T01:30:00Z"],"type":"occurrences"}`
- `sha256:67281c9132f6012c730d37f95a2f4d5426eb42ba0a947e8a01c106435ed94279`: 6 build(s): javascript.cron-parser, php.php-cron-expression, python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=6. Matched cases: none. Answer: `{"occurrences":["2026-10-24T01:30:00+02:00|2026-10-23T23:30:00Z","2026-10-25T01:30:00+02:00|2026-10-24T23:30:00Z","2026-10-26T01:30:00+00:00|2026-10-26T01:30:00Z","2026-10-27T01:30:00+00:00|2026-10-27T01:30:00Z"],"type":"occurrences"}`
- `sha256:e6f40fd7bd9499fd938aa104c813f1380fe32ef71ca16c4858e84cdad01f184a`: 5 build(s): go.robfig-cron, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=5. Matched cases: none. Answer: `{"occurrences":["2026-10-24T01:30:00+02:00|2026-10-23T23:30:00Z","2026-10-25T01:30:00+02:00|2026-10-24T23:30:00Z","2026-10-25T01:30:00+00:00|2026-10-25T01:30:00Z","2026-10-26T01:30:00+00:00|2026-10-26T01:30:00Z"],"type":"occurrences"}`

### `CRON-DST-007` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:56c9bc741ede0f750cfa2234785581e83e6ebb0419db64d5fec7d249a4231f28`: 6 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=6. Matched cases: none. Answer: `{"occurrences":["2011-11-30T12:00:00-10:00|2011-11-30T22:00:00Z","2011-12-31T00:00:00+14:00|2011-12-30T10:00:00Z","2012-01-30T12:00:00+14:00|2012-01-29T22:00:00Z"],"type":"occurrences"}`
- `sha256:66957064bdc5bfa4607e508201a13602476d926a98eb5554b1bf28c336757cd1`: 2 build(s): javascript.cron-parser, php.php-cron-expression. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2011-11-30T12:00:00-10:00|2011-11-30T22:00:00Z","2012-01-30T12:00:00+14:00|2012-01-29T22:00:00Z","2012-03-30T12:00:00+14:00|2012-03-29T22:00:00Z"],"type":"occurrences"}`
- `sha256:ab5c93059b30f7e7fbed13b339afe5600669ef76c1b5f2cd8396f3fe477dc6b1`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, on day 30 of the month"],"type":"occurrences"}`
- `sha256:d82a188c7e1f292a466ca77b8750e34998f0c0df88871c74dfc5417c23cfa15d`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2011-11-30T12:00:00-10:00|2011-11-30T22:00:00Z","2011-12-30T12:00:00-10:00|2011-12-30T22:00:00Z","2012-01-30T12:00:00+14:00|2012-01-29T22:00:00Z"],"type":"occurrences"}`
- `sha256:e342fb255fba7a651c5a98ece9d4a395fa713220ad007ccae88b1e9fdf4da371`: 2 build(s): javascript.croner, javascript.croner-legacyMode-false. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2011-11-30T12:00:00-10:00|2011-11-30T22:00:00Z","2011-12-31T12:00:00+14:00|2011-12-30T22:00:00Z","2012-01-30T12:00:00+14:00|2012-01-29T22:00:00Z"],"type":"occurrences"}`

### `CRON-DST-008` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:033b75f066a67491951f916fdf7844c513ec79628c58b5fa161dd46417225604`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"occurrences":["2022-10-27T00:30:00+03:00|2022-10-26T21:30:00Z","2022-10-28T00:30:00+03:00|2022-10-27T21:30:00Z","2022-10-29T00:30:00+03:00|2022-10-28T21:30:00Z","2022-10-30T00:30:00+03:00|2022-10-29T21:30:00Z"],"type":"occurrences"}`
- `sha256:475af9199dd48e16443d86a743f1df6fb2ba8478c8dae5837c3a752581aceaaa`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:30 AM"],"type":"occurrences"}`

### `CRON-DST-009` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:033b75f066a67491951f916fdf7844c513ec79628c58b5fa161dd46417225604`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"occurrences":["2022-10-27T00:30:00+03:00|2022-10-26T21:30:00Z","2022-10-28T00:30:00+03:00|2022-10-27T21:30:00Z","2022-10-29T00:30:00+03:00|2022-10-28T21:30:00Z","2022-10-30T00:30:00+03:00|2022-10-29T21:30:00Z"],"type":"occurrences"}`
- `sha256:475af9199dd48e16443d86a743f1df6fb2ba8478c8dae5837c3a752581aceaaa`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:30 AM"],"type":"occurrences"}`

### `CRON-DST-010` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:3442d186d918e9ba7f5a7511ce60a5bcd23c61200a23abbdfdb710028b011714`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:30:00+05:45|2025-12-31T18:45:00Z","2026-01-02T00:30:00+05:45|2026-01-01T18:45:00Z","2026-01-03T00:30:00+05:45|2026-01-02T18:45:00Z"],"type":"occurrences"}`
- `sha256:475af9199dd48e16443d86a743f1df6fb2ba8478c8dae5837c3a752581aceaaa`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:30 AM"],"type":"occurrences"}`

### `CRON-DST-011` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:189c0a80a69410f55c24c9d9078c6e6de1aab09c64901c79fdd92122053815e0`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:30:00+08:45|2025-12-31T15:45:00Z","2026-01-02T00:30:00+08:45|2026-01-01T15:45:00Z","2026-01-03T00:30:00+08:45|2026-01-02T15:45:00Z"],"type":"occurrences"}`
- `sha256:475af9199dd48e16443d86a743f1df6fb2ba8478c8dae5837c3a752581aceaaa`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:30 AM"],"type":"occurrences"}`

### `CRON-DST-012` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:67758c5d2b7ca50cc6d9b9a66ec90c4d315c03a4e3dcc0bfbcf10c34b319b7cf`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"occurrences":["1992-09-25T12:00:00+01:00|1992-09-25T11:00:00Z","1992-09-26T12:00:00+01:00|1992-09-26T11:00:00Z","1992-09-27T12:00:00+01:00|1992-09-27T11:00:00Z","1992-09-28T12:00:00+01:00|1992-09-28T11:00:00Z"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`

### `CRON-DST-013` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:8020b5f2b07b36ee9a7ee9cdb68d5fffc7a1523ea4179064e6f0afd3acd35a54`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"occurrences":["2007-03-09T12:00:00-05:00|2007-03-09T17:00:00Z","2007-03-10T12:00:00-05:00|2007-03-10T17:00:00Z","2007-03-11T12:00:00-04:00|2007-03-11T16:00:00Z","2007-03-12T12:00:00-04:00|2007-03-12T16:00:00Z"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`

### `CRON-DST-014` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:1788cfe42c6c43e3ad9f89d6dd5301b627d2720d00330a85c92cca0f84d4c267`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 02:30 AM"],"type":"occurrences"}`
- `sha256:673d99e1932242ff55771541909fb26d4a292354ee5ae7cdfc1465ffdc433971`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-09-05T02:30:00-04:00|2026-09-05T06:30:00Z","2026-09-06T02:30:00-03:00|2026-09-06T05:30:00Z","2026-09-07T02:30:00-03:00|2026-09-07T05:30:00Z","2026-09-08T02:30:00-03:00|2026-09-08T05:30:00Z"],"type":"occurrences"}`

### `CRON-DST-015` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:8a244b7a475eb950454274eb1120c0e9d26a00d7fe88f7b4bb632a402bd55400`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-03-07T23:30:00-03:30|2026-03-08T03:00:00Z","2026-03-08T23:30:00-02:30|2026-03-09T02:00:00Z","2026-03-09T23:30:00-02:30|2026-03-10T02:00:00Z","2026-03-10T23:30:00-02:30|2026-03-11T02:00:00Z"],"type":"occurrences"}`
- `sha256:d6678f8deb7149e5c7ac32ee79f9b60d202d4a50dad41cb71463abade3a07cce`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 11:30 PM"],"type":"occurrences"}`

### `CRON-DST-016` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:3ce0f58d7e204c2f485fa6e68ef15a462cde3b0381df4d4859534186a4033746`: 2 build(s): javascript.croner, javascript.croner-legacyMode-false. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-11-01T01:00:00-04:00|2026-11-01T05:00:00Z","2026-11-01T02:00:00-05:00|2026-11-01T07:00:00Z","2026-11-01T03:00:00-05:00|2026-11-01T08:00:00Z","2026-11-01T04:00:00-05:00|2026-11-01T09:00:00Z","2026-11-01T05:00:00-05:00|2026-11-01T10:00:00Z","2026-11-01T06:00:00-05:00|2026-11-01T11:00:00Z"],"type":"occurrences"}`
- `sha256:abb8fb342d7cfe5c9929cacd7eef915b157afb26a317fca96a823fd6ef830c4e`: 9 build(s): go.robfig-cron, javascript.cron-parser, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=9. Matched cases: none. Answer: `{"occurrences":["2026-11-01T01:00:00-04:00|2026-11-01T05:00:00Z","2026-11-01T01:00:00-05:00|2026-11-01T06:00:00Z","2026-11-01T02:00:00-05:00|2026-11-01T07:00:00Z","2026-11-01T03:00:00-05:00|2026-11-01T08:00:00Z","2026-11-01T04:00:00-05:00|2026-11-01T09:00:00Z","2026-11-01T05:00:00-05:00|2026-11-01T10:00:00Z"],"type":"occurrences"}`
- `sha256:dc50efb601aa3fb1e974ead030f6a9b1bf4d18e1f962374f1e7513d2d384fce3`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:Every hour"],"type":"occurrences"}`
- `sha256:f911397aec6186fbc3fdfd02f3a0c2dcad13b09594419626c1c60fcc8198b5c3`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-11-01T00:00:00-04:00|2026-11-01T04:00:00Z","2026-11-01T01:00:00-04:00|2026-11-01T05:00:00Z","2026-11-01T01:00:00-05:00|2026-11-01T06:00:00Z","2026-11-01T01:00:00-05:00|2026-11-01T06:00:00Z","2026-11-01T01:00:00-05:00|2026-11-01T06:00:00Z","2026-11-01T01:00:00-05:00|2026-11-01T06:00:00Z"],"type":"occurrences"}`

### `CRON-DST-017` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:5fd2936b71798cf65e8e0ebcc7a87a4194a6724f1365d1ca2a6f6b13336a2d61`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-03-08T00:30:00-05:00|2026-03-08T05:30:00Z","2026-03-08T01:00:00-05:00|2026-03-08T06:00:00Z","2026-03-08T01:30:00-05:00|2026-03-08T06:30:00Z","2026-03-08T03:00:00-04:00|2026-03-08T07:00:00Z","2026-03-08T03:30:00-04:00|2026-03-08T07:30:00Z","2026-03-08T04:00:00-04:00|2026-03-08T08:00:00Z","2026-03-08T04:30:00-04:00|2026-03-08T08:30:00Z","2026-03-08T05:00:00-04:00|2026-03-08T09:00:00Z"],"type":"occurrences"}`
- `sha256:c2387550e1cebefd0eb642f478178f40b579e253629d910de61b98b0deaef27e`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:Every 30 minutes"],"type":"occurrences"}`
- `sha256:e8ebad66f7c1a83df205f863822c7e606df35244d7ee509a560341a7703930ff`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-08T00:00:00-05:00|2026-03-08T05:00:00Z","2026-03-08T00:30:00-05:00|2026-03-08T05:30:00Z","2026-03-08T01:00:00-05:00|2026-03-08T06:00:00Z","2026-03-08T01:30:00-05:00|2026-03-08T06:30:00Z","2026-03-08T03:00:00-04:00|2026-03-08T07:00:00Z","2026-03-08T03:30:00-04:00|2026-03-08T07:30:00Z","2026-03-08T04:00:00-04:00|2026-03-08T08:00:00Z","2026-03-08T04:30:00-04:00|2026-03-08T08:30:00Z"],"type":"occurrences"}`

### `CRON-DST-018` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:366041127fd8966ef457959c3de484ec3d3a04f864c9c402c289f543dd1c7a6c`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM"],"type":"occurrences"}`
- `sha256:c55b922221f28a85f069e3f4a8b908f690f923dd8ca37fa8fdfe2372f39c7414`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-02T00:00:00+14:00|2026-01-01T10:00:00Z","2026-01-03T00:00:00+14:00|2026-01-02T10:00:00Z","2026-01-04T00:00:00+14:00|2026-01-03T10:00:00Z"],"type":"occurrences"}`
- `sha256:f09e4c9c324b3e88298ec8ba4fac61be3ccf19ea1e94db4689a3e0b005204423`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:00+14:00|2025-12-31T10:00:00Z","2026-01-02T00:00:00+14:00|2026-01-01T10:00:00Z","2026-01-03T00:00:00+14:00|2026-01-02T10:00:00Z"],"type":"occurrences"}`

### `CRON-DST-019` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:366041127fd8966ef457959c3de484ec3d3a04f864c9c402c289f543dd1c7a6c`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM"],"type":"occurrences"}`
- `sha256:368b350e7f2f92a8547e23147e2688a01d5aa78bb725c29e003af890774fb09d`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-02T00:00:00-11:00|2026-01-02T11:00:00Z","2026-01-03T00:00:00-11:00|2026-01-03T11:00:00Z","2026-01-04T00:00:00-11:00|2026-01-04T11:00:00Z"],"type":"occurrences"}`
- `sha256:d07c5cc0b680bea4e2759dfdc6829eff0f5d3ddd367099e23c5f9caa9ce1a680`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:00-11:00|2026-01-01T11:00:00Z","2026-01-02T00:00:00-11:00|2026-01-02T11:00:00Z","2026-01-03T00:00:00-11:00|2026-01-03T11:00:00Z"],"type":"occurrences"}`

### `CRON-DST-020` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_fold`, `cron.dst_gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:1464222132455d85c1bccda2a4ceb28999154e446ae6676221608ccd67747ff8`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 01:30 AM, only on Sunday"],"type":"occurrences"}`
- `sha256:523c7398664da78d659209b9bbc8278273e6f5692b380bb95b4cfc852e1f1b48`: 4 build(s): javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-03-01T01:30:00+00:00|2026-03-01T01:30:00Z","2026-03-08T01:30:00+00:00|2026-03-08T01:30:00Z","2026-03-15T01:30:00+00:00|2026-03-15T01:30:00Z","2026-03-22T01:30:00+00:00|2026-03-22T01:30:00Z","2026-03-29T02:30:00+01:00|2026-03-29T01:30:00Z"],"type":"occurrences"}`
- `sha256:a541a4d3f716821f3d96909b0c8064770fb0f133223436a46d056cbbccbe7018`: 1 build(s): go.robfig-cron. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-03-01T01:30:00+00:00|2026-03-01T01:30:00Z","2026-03-08T01:30:00+00:00|2026-03-08T01:30:00Z","2026-03-15T01:30:00+00:00|2026-03-15T01:30:00Z","2026-03-22T01:30:00+00:00|2026-03-22T01:30:00Z","2026-04-05T01:30:00+01:00|2026-04-05T00:30:00Z"],"type":"occurrences"}`
- `sha256:e61253ba8fd9e71755e6806bbe2bd1b9eb5623fbdefe036881c108f34da6d6bd`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-01T01:30:00+00:00|2026-03-01T01:30:00Z","2026-03-08T01:30:00+00:00|2026-03-08T01:30:00Z","2026-03-15T01:30:00+00:00|2026-03-15T01:30:00Z","2026-03-22T01:30:00+00:00|2026-03-22T01:30:00Z","2026-03-29T01:30:00+00:00|2026-03-29T01:30:00Z"],"type":"occurrences"}`
- `sha256:fc6cbb0ef7b61dd8bcdb2b9ef4201c75bbf5a0ff08d593b1588177be6c861d06`: 6 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=6. Matched cases: none. Answer: `{"occurrences":["2026-03-01T01:30:00+00:00|2026-03-01T01:30:00Z","2026-03-08T01:30:00+00:00|2026-03-08T01:30:00Z","2026-03-15T01:30:00+00:00|2026-03-15T01:30:00Z","2026-03-22T01:30:00+00:00|2026-03-22T01:30:00Z","2026-03-29T02:00:00+01:00|2026-03-29T01:00:00Z"],"type":"occurrences"}`

### `CRON-EXT-001` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.L`, `cron.dialect`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 5 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser-strict, python.aps.system, python.aps.vendored. Verdicts: non_conformant=5. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:428c577f1e38759d62e4bade345dd4f0a35c7972d17bc0d1754633c17411780f`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 09:00 AM, on the last day of the month"],"type":"occurrences"}`
- `sha256:c3fa8864438577201244cb55369e624145ff7acf2c752fe15e3d40e8d3f0d5b4`: 10 build(s): javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=10. Matched cases: none. Answer: `{"occurrences":["2027-01-31T09:00:00","2027-02-28T09:00:00","2027-03-31T09:00:00","2027-04-30T09:00:00","2027-05-31T09:00:00"],"type":"occurrences"}`

### `CRON-EXT-002` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.L`, `cron.dialect`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 14 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=14. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:6203bfd7fb85e61ab6f602c8f703e325ebb7d2c5ab9c22fe053432fc833a6660`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 09:00 AM, 3 days before the last day of the month"],"type":"occurrences"}`

### `CRON-EXT-003` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.W`, `cron.dialect`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 8 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:0339995f6390767881674c08bc20a340b4336a3c9d1fabafc1480d380384776f`: 7 build(s): javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=7. Matched cases: none. Answer: `{"occurrences":["2026-01-15T09:00:00","2026-02-16T09:00:00","2026-03-16T09:00:00","2026-04-15T09:00:00","2026-05-15T09:00:00","2026-06-15T09:00:00","2026-07-15T09:00:00","2026-08-14T09:00:00"],"type":"occurrences"}`
- `sha256:9be97ced3499c0ce477751c2528e5623e87e630b07773b8f7f1e1331ba58b7ba`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 09:00 AM, on the weekday nearest day 15 of the month"],"type":"occurrences"}`

### `CRON-EXT-004` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.W`, `cron.dialect`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 8 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:8dcf926f0d2d8c5218e960617a82ef902916cbf9c2cc5237d30c2d16dc3d2f12`: 7 build(s): javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=7. Matched cases: none. Answer: `{"occurrences":["2026-07-01T09:00:00","2026-08-03T09:00:00","2026-09-01T09:00:00","2026-10-01T09:00:00"],"type":"occurrences"}`
- `sha256:d6e665fd53f9267bafef48e6db207976ed74e9495a228e6ea47c20daeb340138`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 09:00 AM, on the first weekday of the month"],"type":"occurrences"}`

### `CRON-EXT-005` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.W`, `cron.dialect`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 10 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=10. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:360c01d156ac613005540a13310f74d0c72077bda9438fa3442bd77398b68128`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 09:00 AM, on the last weekday of the month"],"type":"occurrences"}`
- `sha256:b9b0316dcf4055fbd78de3349ab5f7849fc3b54ad330af2933162788b046ec9a`: 4 build(s): javascript.croner, javascript.croner-legacyMode-false, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-01-30T09:00:00","2026-02-27T09:00:00","2026-03-31T09:00:00","2026-04-30T09:00:00","2026-05-29T09:00:00","2026-06-30T09:00:00"],"type":"occurrences"}`
- `sha256:c248bf77fdbb8015f6c8c7261363ee42d0969166ce62ef0e6a78bf3a58106825`: 1 build(s): php.php-cron-expression. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-31T09:00:00","2026-02-02T09:00:00","2026-03-02T09:00:00","2026-05-30T09:00:00","2026-06-01T09:00:00","2026-07-30T09:00:00"],"type":"occurrences"}`

### `CRON-EXT-006` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.hash`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 13 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:091365ebf58e6778b8f9c2718a1bf03494941c50a51167574fb9966fa97ff292`: 1 build(s): javascript.croner. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-01T09:00:00","2026-01-02T09:00:00","2026-01-03T09:00:00","2026-01-04T09:00:00","2026-01-05T09:00:00"],"type":"occurrences"}`
- `sha256:d192288bf845329bb0d03d9cece77b02ece670362ec180a76794102b06f2617e`: 1 build(s): javascript.croner-legacyMode-false. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-16T09:00:00","2026-02-20T09:00:00","2026-03-20T09:00:00","2026-04-17T09:00:00","2026-05-15T09:00:00"],"type":"occurrences"}`
- `sha256:f87cd4f498739d1d33f71435cdbe1f0cd4dda74f1d552be73866664634385fe5`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 09:00 AM, on the third Friday of the month"],"type":"occurrences"}`

### `CRON-EXT-007` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.hash`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 13 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:459211838b0a396029e593665291bc9301d01372de9ac6ea7c573ae35de0d2b8`: 1 build(s): javascript.croner. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-01T09:00:00","2026-01-02T09:00:00","2026-01-03T09:00:00","2026-01-04T09:00:00"],"type":"occurrences"}`
- `sha256:638146fa1ba00bae03c4c1aa307a7611e2dc7ae46a9e4bd05c3b59ccea4042ae`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 09:00 AM, on the fifth Sunday of the month"],"type":"occurrences"}`
- `sha256:9eaef813a4e0b02b92c61a9e758798ea006deeae7f76a24893d44e8e51524713`: 1 build(s): javascript.croner-legacyMode-false. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-03-29T09:00:00","2026-05-31T09:00:00","2026-08-30T09:00:00","2026-11-29T09:00:00"],"type":"occurrences"}`

### `CRON-EXT-008` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.L`, `cron.dialect`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 13 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:05bb13a98d15d45ff54e28eb9415c608a10b68032feb44d0ad5484b35b25db3c`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 09:00 AM, on the last Friday of the month"],"type":"occurrences"}`
- `sha256:091365ebf58e6778b8f9c2718a1bf03494941c50a51167574fb9966fa97ff292`: 1 build(s): javascript.croner. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-01T09:00:00","2026-01-02T09:00:00","2026-01-03T09:00:00","2026-01-04T09:00:00","2026-01-05T09:00:00"],"type":"occurrences"}`
- `sha256:5d6221146a064c1a4732ce370d09108ef9976504b35b3e7efe0ca4c9ab15ebd4`: 1 build(s): javascript.croner-legacyMode-false. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-30T09:00:00","2026-02-27T09:00:00","2026-03-27T09:00:00","2026-04-24T09:00:00","2026-05-29T09:00:00"],"type":"occurrences"}`

### `CRON-EXT-009` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.qmark`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 13 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:208b72d5451937ca7c9d63c97b12ca7abf961a11413070eba3b52b9cc7afc798`: 1 build(s): javascript.croner-legacyMode-false. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-05T12:00:00","2026-01-12T12:00:00","2026-01-19T12:00:00","2026-01-26T12:00:00"],"type":"occurrences"}`
- `sha256:b038825fdf58f7eac62b9e67a446b752576dc8fa5f4d43a2ceefb022674c1373`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, only on Monday"],"type":"occurrences"}`
- `sha256:f9053c060f66932a1f9dc3049f5af826a6825a910c79e6c45988a53c6426df12`: 1 build(s): javascript.croner. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-01T12:00:00","2026-01-02T12:00:00","2026-01-03T12:00:00","2026-01-04T12:00:00"],"type":"occurrences"}`

### `CRON-EXT-010` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `cron.dialect`, `cron.qmark`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 13 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant_admissible=13. Matched cases: reject. Answer: `{"type":"rejection"}`
- `sha256:b170e8b18fa6b84cedf82c112207b329ad712b4370e852da3778d89c97fca9bb`: 2 build(s): javascript.croner, javascript.croner-legacyMode-false. Verdicts: conformant_admissible=2. Matched cases: accept-as-star. Answer: `{"occurrences":["2026-01-01T12:00:00","2026-01-02T12:00:00","2026-01-03T12:00:00"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`

### `CRON-EXT-011` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.hash_H`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 15 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, javascript.cronstrue, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=15. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 1 build(s): javascript.cron-parser. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"type":"accepted"}`

### `CRON-EXT-013` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `cron.L`, `cron.dialect`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 15 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant_admissible=15. Matched cases: last-day-of-week-of-month. Answer: `{"type":"rejection"}`
- `sha256:9125582cbb2dee5bd558ff6707941934af63c3d5308ba6a0973079bb42015814`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 09:00 AM, only on Saturday"],"type":"occurrences"}`

### `CRON-FIELDS-001` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:30a958c08f5cd404b161e5a6e1e512949ce93af3224925f1e6a88af61bedf1cf`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-01-01T10:15:00","2026-01-02T10:15:00","2026-01-03T10:15:00","2026-01-04T10:15:00"],"type":"occurrences"}`
- `sha256:33d8c85d7a31b8ae782da998203146c2eb14d048921173697df3522a21775f31`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 10:15 AM"],"type":"occurrences"}`

### `CRON-FIELDS-002` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.sixth_field`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 4 build(s): go.robfig-cron, php.php-cron-expression, python.aps.system, python.aps.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:30a958c08f5cd404b161e5a6e1e512949ce93af3224925f1e6a88af61bedf1cf`: 7 build(s): go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=7. Matched cases: none. Answer: `{"occurrences":["2026-01-01T10:15:00","2026-01-02T10:15:00","2026-01-03T10:15:00","2026-01-04T10:15:00"],"type":"occurrences"}`
- `sha256:33d8c85d7a31b8ae782da998203146c2eb14d048921173697df3522a21775f31`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 10:15 AM"],"type":"occurrences"}`
- `sha256:3e4761bccc2a0cea32ce3608d9ddee9d15eaaade5ee01d552a3bbdc83e344e66`: 4 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-01-10T15:00:00","2026-01-10T15:00:01","2026-01-10T15:00:02","2026-01-10T15:00:03"],"type":"occurrences"}`

### `CRON-FIELDS-003` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.field_count`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 13 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:364d71d817b765305bd84e662c7fd3dc881e9c250af14c7de2714bacde440064`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, only on Monday, only in 2027"],"type":"occurrences"}`
- `sha256:97cb1cbeac1e9a3487f034d0fac08a03ba2af30311eae68fcb1709867ab2a81d`: 1 build(s): javascript.croner. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2027-01-01T12:00:00","2027-01-02T12:00:00","2027-01-03T12:00:00","2027-01-04T12:00:00"],"type":"occurrences"}`
- `sha256:c863dae0c0568e96446ce03e10c490123f555495df23b003a2188755722291d3`: 1 build(s): javascript.croner-legacyMode-false. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2027-01-04T12:00:00","2027-01-11T12:00:00","2027-01-18T12:00:00","2027-01-25T12:00:00"],"type":"occurrences"}`

### `CRON-FIELDS-004` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.seconds`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 4 build(s): go.robfig-cron, php.php-cron-expression, python.aps.system, python.aps.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:7bfe19c7e59a0b7ae1d1e10767e690d7c9183ffebfe4035646e5e9cca7679d09`: 7 build(s): go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=7. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:15","2026-01-01T00:00:30","2026-01-01T00:00:45","2026-01-01T00:01:00","2026-01-01T00:01:15","2026-01-01T00:01:30"],"type":"occurrences"}`
- `sha256:96c7ee393927af108d7a7e83b61a908cce38105d0c85ba5dad9fd27ace7234e2`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:Every 15 seconds"],"type":"occurrences"}`
- `sha256:d111527f5e4dc40ff53637cd0bcacf450b6a648568446fbab5a2c5a0dcd7c631`: 4 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:01","2026-01-01T00:00:02","2026-01-01T00:00:03","2026-01-01T00:00:04","2026-01-01T00:00:05","2026-01-01T00:00:06"],"type":"occurrences"}`

### `CRON-FIELDS-005` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 15 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, javascript.cronstrue, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=15. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 1 build(s): javascript.cron-parser. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"type":"accepted"}`

### `CRON-FIELDS-007` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.sixth_field`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 15 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=15. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:bcdb8e17f79af98b0f36e94e2d1c0bfb123f1ea7c959a2b649b89bbc0709cad9`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM, on day 1 of the month, only in January, only in 2027"],"type":"occurrences"}`

### `CRON-FIELDS-008` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 4 build(s): python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:366041127fd8966ef457959c3de484ec3d3a04f864c9c402c289f543dd1c7a6c`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM"],"type":"occurrences"}`
- `sha256:69ee052abf7c1f0db67c08d5d64d2ad0dcd1d2ace3d160c01d8a79b275bde152`: 11 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-02T00:00:00","2026-01-03T00:00:00","2026-01-04T00:00:00","2026-01-05T00:00:00"],"type":"occurrences"}`

### `CRON-FIELDS-009` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 4 build(s): python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:4db9501f66e651b678e27dda822f6db39be8aa8bb5b0b3d08fa4699bbac71da9`: 11 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2027-01-01T00:00:00","2028-01-01T00:00:00","2029-01-01T00:00:00","2030-01-01T00:00:00"],"type":"occurrences"}`
- `sha256:61c59dc20a08532fe767854a9b18df0a285eb3d2ebdc9fa103fb8ca5c3ac90d6`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, on day 1 of the month, only in January"],"type":"occurrences"}`

### `CRON-FIELDS-010` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 4 build(s): python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:d1f2e203769446c7c6b924f0c13e856ab1ca1c82663f92a76a62e676d9eee75f`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, on day 1 of the month"],"type":"occurrences"}`
- `sha256:f7e796a542f6b9bf36a8f7e35173981ff96fe80c0543e34ea5bde9ec70c624c1`: 11 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-02-01T00:00:00","2026-03-01T00:00:00","2026-04-01T00:00:00","2026-05-01T00:00:00"],"type":"occurrences"}`

### `CRON-FIELDS-011` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 4 build(s): python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a3b2ea8ae3015962d1481216c239ca842c85aae28d9a4a0050aa2d6cc9460cc2`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, only on Sunday"],"type":"occurrences"}`
- `sha256:af9cbce8f90d088e2f3ce12caab900a6028d69cab41efa603279502b3ed5d65f`: 11 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-04T00:00:00","2026-01-11T00:00:00","2026-01-18T00:00:00","2026-01-25T00:00:00"],"type":"occurrences"}`

### `CRON-FIELDS-012` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 4 build(s): python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:dc50efb601aa3fb1e974ead030f6a9b1bf4d18e1f962374f1e7513d2d384fce3`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:Every hour"],"type":"occurrences"}`
- `sha256:f7d4ed5e47cb24a304ff25893e66168b90e5eda097e86ea189ea76c861f29086`: 11 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-01T01:00:00","2026-01-01T02:00:00","2026-01-01T03:00:00","2026-01-01T04:00:00"],"type":"occurrences"}`

### `CRON-FIELDS-013` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 15 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant_admissible=15. Matched cases: reject. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"type":"accepted"}`

### `CRON-INV-007` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `cron.empty_set`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 9 build(s): go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant_admissible=9. Matched cases: error-at-parse. Answer: `{"type":"rejection"}`
- `sha256:1f05c363d7b1ce98b6136095c2ce84c4b707ae9fb8f01d9c2d5d19ea94c62a31`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, on day 30 of the month, only in February"],"type":"occurrences"}`
- `sha256:9d618fb92a708381628b5351f699f37b50ae839f99d31350a3f77e6feb118010`: 5 build(s): go.robfig-cron, javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored. Verdicts: conformant_admissible=5. Matched cases: empty. Answer: `{"occurrences":[],"type":"occurrences"}`

### `CRON-INV-009` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 15 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, javascript.cronstrue, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=15. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 1 build(s): javascript.cron-parser. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"type":"accepted"}`

### `CRON-INV-010` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 15 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=15. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"type":"accepted"}`

### `CRON-INV-011` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `cron.empty_set`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 9 build(s): go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant_admissible=9. Matched cases: error-at-parse. Answer: `{"type":"rejection"}`
- `sha256:9d618fb92a708381628b5351f699f37b50ae839f99d31350a3f77e6feb118010`: 5 build(s): go.robfig-cron, javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored. Verdicts: conformant_admissible=5. Matched cases: empty. Answer: `{"occurrences":[],"type":"occurrences"}`
- `sha256:a9f63fd9dbe5975580cd5c108959bef58cb1f876624e51b86137fc7dec841a41`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, on day 31 of the month, only in April"],"type":"occurrences"}`

### `CRON-INV-012` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 3 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict, javascript.cronstrue. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:b170e8b18fa6b84cedf82c112207b329ad712b4370e852da3778d89c97fca9bb`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-01-01T12:00:00","2026-01-02T12:00:00","2026-01-03T12:00:00"],"type":"occurrences"}`

### `CRON-STEP-001` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:3248413ca57ae612480600626f345c057bc06b1a3eec287f71015ceffb1fbf9f`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:00","2026-01-01T00:35:00","2026-01-01T01:00:00","2026-01-01T01:35:00","2026-01-01T02:00:00","2026-01-01T02:35:00"],"type":"occurrences"}`
- `sha256:704b50bfab4d9d5aecfd49cda35d627ab92accb59e82e7fe6dc1ca6e5fc44005`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:35:00","2026-01-01T01:00:00","2026-01-01T01:35:00","2026-01-01T02:00:00","2026-01-01T02:35:00","2026-01-01T03:00:00"],"type":"occurrences"}`
- `sha256:8849b2fe2bf9a5a5abb857a714376d8eeb3d7bfb4f2e4369c9b9e8f711b71953`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:Every 35 minutes"],"type":"occurrences"}`

### `CRON-STEP-002` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.bare_start_step`, `cron.dialect`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 5 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression. Verdicts: non_conformant=5. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:4cf38ef5f5e03b11c202a782b72c7487f86ac141cff38e7b6c579b1f2002ed96`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:Every 20 minutes, starting at 5 minutes past the hour"],"type":"occurrences"}`
- `sha256:88f6ccf3be2a5c4995b6403a26a6caf49b0d141ff0f5105b18d7ba73299c9ab4`: 10 build(s): go.robfig-cron, javascript.cron-parser, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=10. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:05:00","2026-01-01T00:25:00","2026-01-01T00:45:00","2026-01-01T01:05:00","2026-01-01T01:25:00","2026-01-01T01:45:00"],"type":"occurrences"}`

### `CRON-STEP-003` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.bare_start_step`, `cron.dialect`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 6 build(s): go.robfig-cron, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored. Verdicts: non_conformant=6. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:14bae1287aef995356008930fdb05c75ca694524e26579dd54c13e579310aad3`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:Every second"],"type":"occurrences"}`
- `sha256:384e2abffe5de47dd808f64eccfa2848dd17c404be0a61346c8c0c0a9947c18e`: 9 build(s): go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=9. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:01","2026-01-01T00:00:02","2026-01-01T00:00:03"],"type":"occurrences"}`

### `CRON-STEP-004` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.step_gt_field`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 6 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored. Verdicts: non_conformant=6. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a9db9a20475a787621adf1d535eea4f7f81db56cd1773be4535d0ce0717d68f0`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:Every 90 minutes"],"type":"occurrences"}`
- `sha256:f5cc06c13921cfb443f8b0fd06b481fdeee10f7a2e8bd1f300c8369fc8324a5e`: 1 build(s): php.php-cron-expression. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:30:00","2026-01-01T01:30:00","2026-01-01T02:30:00","2026-01-01T03:30:00"],"type":"occurrences"}`
- `sha256:f7d4ed5e47cb24a304ff25893e66168b90e5eda097e86ea189ea76c861f29086`: 8 build(s): go.robfig-cron, javascript.cron-parser, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=8. Matched cases: none. Answer: `{"occurrences":["2026-01-01T01:00:00","2026-01-01T02:00:00","2026-01-01T03:00:00","2026-01-01T04:00:00"],"type":"occurrences"}`

### `CRON-STEP-005` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 15 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=15. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"type":"accepted"}`

### `CRON-STEP-006` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:1c1c04185db19b2f5c1dd87e7b99ea692c16616b0b591edd7e2b7d505c543e25`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:On the hour, every 2 hours, between 10:00 AM and 04:00 PM"],"type":"occurrences"}`
- `sha256:2dca37733b5a5a14d4565da234cf00eb3ab22e313440e0d7d749707f12ddf683`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-01-01T10:00:00","2026-01-01T12:00:00","2026-01-01T14:00:00","2026-01-01T16:00:00","2026-01-02T10:00:00"],"type":"occurrences"}`

### `CRON-STEP-007` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `cron.dialect`, `cron.range_wrap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 11 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=11. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:37cf56009428703304351431de02ae1cd0d3e8fa46d489c46d0aee707e37c783`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:On the hour, every 2 hours, between 10:00 PM and 02:00 AM"],"type":"occurrences"}`
- `sha256:81e14bee451b5fdb8884632ae0cefcb5b20ec5ebfa7af985a11e8a39c73e1e2f`: 4 build(s): python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-01-01T02:00:00","2026-01-01T22:00:00","2026-01-02T00:00:00","2026-01-02T02:00:00","2026-01-02T22:00:00"],"type":"occurrences"}`

### `CRON-STEP-008` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:48f23b96f8cd3c9f28c58e649fb3961746124563658633e7e2e483827f51e228`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:Every minute"],"type":"occurrences"}`
- `sha256:4d2666675d3225d73237afe64976c27c7cfe5e5e549381e0dbf368ff93f066f0`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:01:00","2026-01-01T00:02:00","2026-01-01T00:03:00"],"type":"occurrences"}`
- `sha256:bf2af52a13a6e90e8031f1f9895a5d50470b79388071ef7c4908587e1643d8b2`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:00","2026-01-01T00:01:00","2026-01-01T00:02:00"],"type":"occurrences"}`

### `CRON-STEP-009` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:145c9b683b0c89664f60fd0491d1f2a98840b76776106c4a71cfe32ee3e78197`: 9 build(s): go.robfig-cron, javascript.cron-parser, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=9. Matched cases: none. Answer: `{"occurrences":["2026-01-11T00:00:00","2026-01-21T00:00:00","2026-01-31T00:00:00","2026-02-01T00:00:00","2026-02-11T00:00:00","2026-02-21T00:00:00","2026-03-01T00:00:00","2026-03-11T00:00:00"],"type":"occurrences"}`
- `sha256:501c1a6e4da9c1b1889e0e9f8cbf8c165289f9435f842d24e1d59096cb2026bc`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, every 10 days in a month"],"type":"occurrences"}`
- `sha256:6db8352556b20e6d7c11936d7951024ebb53a9ecb250364377670a4147488834`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:00","2026-01-11T00:00:00","2026-01-21T00:00:00","2026-01-31T00:00:00","2026-02-01T00:00:00","2026-02-11T00:00:00","2026-02-21T00:00:00","2026-03-01T00:00:00"],"type":"occurrences"}`
- `sha256:c94250f59eb8e79ad5e169926b961f9e30b42f9bcb71ada9dfedcf8ac47efd76`: 2 build(s): javascript.croner, javascript.croner-legacyMode-false. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-11T00:00:00","2026-01-21T00:00:00","2026-01-31T00:00:00","2026-02-01T00:00:00","2026-02-11T00:00:00","2026-02-21T00:00:00","2026-03-11T00:00:00","2026-03-21T00:00:00"],"type":"occurrences"}`

### `CRON-STEP-010` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:91e6223f951c04f24679cc55c1c1522671885071aae472c084be350bb7df1652`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:00","2026-01-01T02:00:00","2026-01-01T04:00:00","2026-01-01T06:00:00","2026-01-01T23:00:00","2026-01-02T00:00:00"],"type":"occurrences"}`
- `sha256:97dcd20ecfab0ea47f380c58978bd5aaf37462f5fb7eb9211c3db58a0de59d4a`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:On the hour, every 2 hours, between 12:00 AM and 06:00 AM and at 11:00 PM"],"type":"occurrences"}`
- `sha256:d13706c4e256233254829b9b673e81692a301aca88a0f001c55305a10cb95976`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-01-01T02:00:00","2026-01-01T04:00:00","2026-01-01T06:00:00","2026-01-01T23:00:00","2026-01-02T00:00:00","2026-01-02T02:00:00"],"type":"occurrences"}`

### `CRON-STEP-011` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 14 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=14. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"type":"accepted"}`

### `CRON-STEP-012` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:9607de9d626e948fa4e069b36c97ecb764b49b10c2a5e4ecd9bb498715ecadd1`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 AM, on day 1 of the month, every 3 months"],"type":"occurrences"}`
- `sha256:e319e2c8d2a9689e7118f232c22b3d0d5ad99a9f6dac59b17bd9b66cd9ff301c`: 11 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=11. Matched cases: none. Answer: `{"occurrences":["2026-04-01T00:00:00","2026-07-01T00:00:00","2026-10-01T00:00:00","2027-01-01T00:00:00","2027-04-01T00:00:00","2027-07-01T00:00:00"],"type":"occurrences"}`
- `sha256:ed60231debbe02d70f1794f9e1597f066fede878da41e0fcdd11aed239d64728`: 2 build(s): python.aps.system, python.aps.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-01T00:00:00","2026-04-01T00:00:00","2026-07-01T00:00:00","2026-10-01T00:00:00","2027-01-01T00:00:00","2027-04-01T00:00:00"],"type":"occurrences"}`

### `RRULE-BY-001` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:213b5acb3935accbf266515adec342469345fd69022a1999bb2a1fb96007788b`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-09-05T09:00:00-04:00|1997-09-05T13:00:00Z","1997-10-03T09:00:00-04:00|1997-10-03T13:00:00Z","1997-11-07T09:00:00-05:00|1997-11-07T14:00:00Z","1997-12-05T09:00:00-05:00|1997-12-05T14:00:00Z","1998-01-02T09:00:00-05:00|1998-01-02T14:00:00Z","1998-02-06T09:00:00-05:00|1998-02-06T14:00:00Z","1998-03-06T09:00:00-05:00|1998-03-06T14:00:00Z","1998-04-03T09:00:00-05:00|1998-04-03T14:00:00Z","1998-05-01T09:00:00-04:00|1998-05-01T13:00:00Z","1998-06-05T09:00:00-04:00|1998-06-05T13:00:00Z"],"type":"occurrences"}`
- `sha256:d8a0bee56766fb8558f24d1c95053dca38732190d86cf12e5e5b7e78f8b03802`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-05T09:00:00+00:00|1997-09-05T09:00:00Z","1997-10-03T09:00:00+00:00|1997-10-03T09:00:00Z","1997-11-07T09:00:00+00:00|1997-11-07T09:00:00Z","1997-12-05T09:00:00+00:00|1997-12-05T09:00:00Z","1998-01-02T09:00:00+00:00|1998-01-02T09:00:00Z","1998-02-06T09:00:00+00:00|1998-02-06T09:00:00Z","1998-03-06T09:00:00+00:00|1998-03-06T09:00:00Z","1998-04-03T09:00:00+00:00|1998-04-03T09:00:00Z","1998-05-01T09:00:00+00:00|1998-05-01T09:00:00Z","1998-06-05T09:00:00+00:00|1998-06-05T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-002` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:7e0d75598f69276171e943cbecd9df2c26e26c91b8fcf91d3b293e2d1e3ecf19`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-22T09:00:00+00:00|1997-09-22T09:00:00Z","1997-10-20T09:00:00+00:00|1997-10-20T09:00:00Z","1997-11-17T09:00:00+00:00|1997-11-17T09:00:00Z","1997-12-22T09:00:00+00:00|1997-12-22T09:00:00Z"],"type":"occurrences"}`
- `sha256:adf87f72879a3c28831014c3e76d22e419aeb156c01808f50cbfc10106796485`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-09-22T09:00:00-04:00|1997-09-22T13:00:00Z","1997-10-20T09:00:00-04:00|1997-10-20T13:00:00Z","1997-11-17T09:00:00-05:00|1997-11-17T14:00:00Z","1997-12-22T09:00:00-05:00|1997-12-22T14:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-003` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:648858e51bf99ecea4c82dc5ea9f2917eb8049a0db692a7227e4b982000836af`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-03-29T09:00:00-04:00|2026-03-29T13:00:00Z","2026-05-31T09:00:00-04:00|2026-05-31T13:00:00Z","2026-08-30T09:00:00-04:00|2026-08-30T13:00:00Z","2026-11-29T09:00:00-05:00|2026-11-29T14:00:00Z","2027-01-31T09:00:00-05:00|2027-01-31T14:00:00Z"],"type":"occurrences"}`
- `sha256:83b2b45aa9adc0dd93632146c2e25242d48f52dcbcde01ba350039c93e18129f`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-29T09:00:00+00:00|2026-03-29T09:00:00Z","2026-05-31T09:00:00+00:00|2026-05-31T09:00:00Z","2026-08-30T09:00:00+00:00|2026-08-30T09:00:00Z","2026-11-29T09:00:00+00:00|2026-11-29T09:00:00Z","2027-01-31T09:00:00+00:00|2027-01-31T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-004` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:9ac07d99b7ee35a4a41c260a5c1a3785d8413656b3fb1d48e20b1c0985ab98ce`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-25T09:00:00+00:00|2026-01-25T09:00:00Z","2026-02-22T09:00:00+00:00|2026-02-22T09:00:00Z","2026-03-29T09:00:00+00:00|2026-03-29T09:00:00Z","2026-04-26T09:00:00+00:00|2026-04-26T09:00:00Z","2026-05-31T09:00:00+00:00|2026-05-31T09:00:00Z"],"type":"occurrences"}`
- `sha256:ec43103870767c3ae365a0942447396e80e46e3213afd4557106b096b0669ae6`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-01-25T09:00:00-05:00|2026-01-25T14:00:00Z","2026-02-22T09:00:00-05:00|2026-02-22T14:00:00Z","2026-03-29T09:00:00-04:00|2026-03-29T13:00:00Z","2026-04-26T09:00:00-04:00|2026-04-26T13:00:00Z","2026-05-31T09:00:00-04:00|2026-05-31T13:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-005` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:a9edca6ced800dacaa858978b27f8048e9ac20fdef9196fbfaba7c1538102c8f`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-31T09:00:00+00:00|2026-01-31T09:00:00Z","2026-03-31T09:00:00+00:00|2026-03-31T09:00:00Z","2026-05-31T09:00:00+00:00|2026-05-31T09:00:00Z","2026-07-31T09:00:00+00:00|2026-07-31T09:00:00Z","2026-08-31T09:00:00+00:00|2026-08-31T09:00:00Z","2026-10-31T09:00:00+00:00|2026-10-31T09:00:00Z"],"type":"occurrences"}`
- `sha256:e248d0bf87267a69698c306e1dda3895d14ca4e4363ebca39b31e6de33791691`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-01-31T09:00:00-05:00|2026-01-31T14:00:00Z","2026-03-31T09:00:00-04:00|2026-03-31T13:00:00Z","2026-05-31T09:00:00-04:00|2026-05-31T13:00:00Z","2026-07-31T09:00:00-04:00|2026-07-31T13:00:00Z","2026-08-31T09:00:00-04:00|2026-08-31T13:00:00Z","2026-10-31T09:00:00-04:00|2026-10-31T13:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-006` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:87fddc0a4aceba0e58917e5a2e04a20bb74b508bf058fbd972a23abe7cf9424d`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-30T09:00:00+00:00|2026-01-30T09:00:00Z","2026-03-30T09:00:00+00:00|2026-03-30T09:00:00Z","2026-04-30T09:00:00+00:00|2026-04-30T09:00:00Z","2026-05-30T09:00:00+00:00|2026-05-30T09:00:00Z","2026-06-30T09:00:00+00:00|2026-06-30T09:00:00Z"],"type":"occurrences"}`
- `sha256:ea13f04a1b1fbdc36b627c80f8b70fe8aeb604b2ab7e994fc0673aa777d9abb9`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-01-30T09:00:00-05:00|2026-01-30T14:00:00Z","2026-03-30T09:00:00-04:00|2026-03-30T13:00:00Z","2026-04-30T09:00:00-04:00|2026-04-30T13:00:00Z","2026-05-30T09:00:00-04:00|2026-05-30T13:00:00Z","2026-06-30T09:00:00-04:00|2026-06-30T13:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-007` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:1af07b6bc991783409b431f85a45a081c897c6d017149a85c72aca2b5bf69b11`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2027-01-29T09:00:00-05:00|2027-01-29T14:00:00Z","2027-03-29T09:00:00-04:00|2027-03-29T13:00:00Z","2027-04-29T09:00:00-04:00|2027-04-29T13:00:00Z","2027-05-29T09:00:00-04:00|2027-05-29T13:00:00Z","2027-06-29T09:00:00-04:00|2027-06-29T13:00:00Z","2027-07-29T09:00:00-04:00|2027-07-29T13:00:00Z","2027-08-29T09:00:00-04:00|2027-08-29T13:00:00Z","2027-09-29T09:00:00-04:00|2027-09-29T13:00:00Z","2027-10-29T09:00:00-04:00|2027-10-29T13:00:00Z","2027-11-29T09:00:00-05:00|2027-11-29T14:00:00Z","2027-12-29T09:00:00-05:00|2027-12-29T14:00:00Z","2028-01-29T09:00:00-05:00|2028-01-29T14:00:00Z","2028-02-29T09:00:00-05:00|2028-02-29T14:00:00Z","2028-03-29T09:00:00-04:00|2028-03-29T13:00:00Z"],"type":"occurrences"}`
- `sha256:b0a2db6a2906338f63ce2b6c1ca66a14c5a864cff5aa8e4c5b9633a0d019498a`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2027-01-29T09:00:00+00:00|2027-01-29T09:00:00Z","2027-03-29T09:00:00+00:00|2027-03-29T09:00:00Z","2027-04-29T09:00:00+00:00|2027-04-29T09:00:00Z","2027-05-29T09:00:00+00:00|2027-05-29T09:00:00Z","2027-06-29T09:00:00+00:00|2027-06-29T09:00:00Z","2027-07-29T09:00:00+00:00|2027-07-29T09:00:00Z","2027-08-29T09:00:00+00:00|2027-08-29T09:00:00Z","2027-09-29T09:00:00+00:00|2027-09-29T09:00:00Z","2027-10-29T09:00:00+00:00|2027-10-29T09:00:00Z","2027-11-29T09:00:00+00:00|2027-11-29T09:00:00Z","2027-12-29T09:00:00+00:00|2027-12-29T09:00:00Z","2028-01-29T09:00:00+00:00|2028-01-29T09:00:00Z","2028-02-29T09:00:00+00:00|2028-02-29T09:00:00Z","2028-03-29T09:00:00+00:00|2028-03-29T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-008` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:094661178218407ab2fa53a2928213516742d6e14704edfcd6b1e57537cbf3f3`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2027-01-31T09:00:00-05:00|2027-01-31T14:00:00Z","2027-02-28T09:00:00-05:00|2027-02-28T14:00:00Z","2027-03-31T09:00:00-04:00|2027-03-31T13:00:00Z","2027-04-30T09:00:00-04:00|2027-04-30T13:00:00Z","2027-05-31T09:00:00-04:00|2027-05-31T13:00:00Z"],"type":"occurrences"}`
- `sha256:3f8050a54cbda9991f17785aa57019ec28b98b2faec0957f38afae743ddb5e52`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2027-01-31T09:00:00+00:00|2027-01-31T09:00:00Z","2027-02-28T09:00:00+00:00|2027-02-28T09:00:00Z","2027-03-31T09:00:00+00:00|2027-03-31T09:00:00Z","2027-04-30T09:00:00+00:00|2027-04-30T09:00:00Z","2027-05-31T09:00:00+00:00|2027-05-31T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-009` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:62095d3b024c08f509c43d413cf006cbbd59737ecd4636df8fe5c83829ff5725`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-30T09:00:00+00:00|1997-09-30T09:00:00Z","1997-10-01T09:00:00+00:00|1997-10-01T09:00:00Z","1997-10-31T09:00:00+00:00|1997-10-31T09:00:00Z","1997-11-01T09:00:00+00:00|1997-11-01T09:00:00Z","1997-11-30T09:00:00+00:00|1997-11-30T09:00:00Z"],"type":"occurrences"}`
- `sha256:fe12619254a326c0263b43ec290985d31f78b6b8beaa82872ec3c69e5256e963`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-09-30T09:00:00-04:00|1997-09-30T13:00:00Z","1997-10-01T09:00:00-04:00|1997-10-01T13:00:00Z","1997-10-31T09:00:00-05:00|1997-10-31T14:00:00Z","1997-11-01T09:00:00-05:00|1997-11-01T14:00:00Z","1997-11-30T09:00:00-05:00|1997-11-30T14:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-010` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:6ca46159ce8f81555461605d05ca5b9e6314568a2e06ffc619a1c12f2d2617a6`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2024-02-29T09:00:00-05:00|2024-02-29T14:00:00Z","2028-02-29T09:00:00-05:00|2028-02-29T14:00:00Z","2032-02-29T09:00:00-05:00|2032-02-29T14:00:00Z"],"type":"occurrences"}`
- `sha256:a61d01129b9cdc7976e9efb84ffa0128de2ea0369a891b312fb44bfe32453683`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2024-02-29T09:00:00+00:00|2024-02-29T09:00:00Z","2028-02-29T09:00:00+00:00|2028-02-29T09:00:00Z","2032-02-29T09:00:00+00:00|2032-02-29T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-012` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:4ea634293fdaa8d80931cd9eadafbf8689078857fc44030e55f2a05fee9f9a02`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-09-04T09:00:00-04:00|1997-09-04T13:00:00Z","1997-10-07T09:00:00-04:00|1997-10-07T13:00:00Z","1997-11-06T09:00:00-05:00|1997-11-06T14:00:00Z"],"type":"occurrences"}`
- `sha256:a7909c8ff069d04828a7a4c442f6bdd092b6d477e806191eb17639e77e50e337`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-04T09:00:00+00:00|1997-09-04T09:00:00Z","1997-10-07T09:00:00+00:00|1997-10-07T09:00:00Z","1997-11-06T09:00:00+00:00|1997-11-06T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-013` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:b20ebb68eae07a15736d06a1284c7b74e1e3042ae4aab7c869bf62a3e7a38972`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-09-29T09:00:00-04:00|1997-09-29T13:00:00Z","1997-10-30T09:00:00-05:00|1997-10-30T14:00:00Z","1997-11-27T09:00:00-05:00|1997-11-27T14:00:00Z","1997-12-30T09:00:00-05:00|1997-12-30T14:00:00Z","1998-01-29T09:00:00-05:00|1998-01-29T14:00:00Z","1998-02-26T09:00:00-05:00|1998-02-26T14:00:00Z","1998-03-30T09:00:00-05:00|1998-03-30T14:00:00Z"],"type":"occurrences"}`
- `sha256:dc042eaaa510f46d01c549b17deec530c9cbcc314c69ede708f700c1a0ae9d31`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-29T09:00:00+00:00|1997-09-29T09:00:00Z","1997-10-30T09:00:00+00:00|1997-10-30T09:00:00Z","1997-11-27T09:00:00+00:00|1997-11-27T09:00:00Z","1997-12-30T09:00:00+00:00|1997-12-30T09:00:00Z","1998-01-29T09:00:00+00:00|1998-01-29T09:00:00Z","1998-02-26T09:00:00+00:00|1998-02-26T09:00:00Z","1998-03-30T09:00:00+00:00|1998-03-30T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-014` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:59ab77914748640523be3daf89fde6dc1295597b4440f21722b2356a00a85cd6`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-09T09:00:00+00:00|2026-01-09T09:00:00Z","2026-01-16T09:00:00+00:00|2026-01-16T09:00:00Z","2026-01-23T09:00:00+00:00|2026-01-23T09:00:00Z","2026-01-30T09:00:00+00:00|2026-01-30T09:00:00Z"],"type":"occurrences"}`
- `sha256:6ed87d95f8f40087ad15fe6802810b6800b4c7501ae5cc0145481e041198798d`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-01-09T09:00:00-05:00|2026-01-09T14:00:00Z","2026-01-16T09:00:00-05:00|2026-01-16T14:00:00Z","2026-01-23T09:00:00-05:00|2026-01-23T14:00:00Z","2026-01-30T09:00:00-05:00|2026-01-30T14:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-017` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:6cfc2740d95ff9f51e1c2d6fa1f13c6288a1fe4774b55c07f898904df82610a5`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-08-05T09:00:00+00:00|1997-08-05T09:00:00Z","1997-08-10T09:00:00+00:00|1997-08-10T09:00:00Z","1997-08-19T09:00:00+00:00|1997-08-19T09:00:00Z","1997-08-24T09:00:00+00:00|1997-08-24T09:00:00Z"],"type":"occurrences"}`
- `sha256:b8d8b285a14dfc6ff90a42479cce532d64cad1c5de3f6bf47cbca085c34b2989`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-08-05T09:00:00-04:00|1997-08-05T13:00:00Z","1997-08-10T09:00:00-04:00|1997-08-10T13:00:00Z","1997-08-19T09:00:00-04:00|1997-08-19T13:00:00Z","1997-08-24T09:00:00-04:00|1997-08-24T13:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-018` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:0784d567b0de945b9764e0ed81ba5e80e9cf5bc26af0debfb88937bf2dde8459`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-08-05T09:00:00-04:00|1997-08-05T13:00:00Z","1997-08-17T09:00:00-04:00|1997-08-17T13:00:00Z","1997-08-19T09:00:00-04:00|1997-08-19T13:00:00Z","1997-08-31T09:00:00-04:00|1997-08-31T13:00:00Z"],"type":"occurrences"}`
- `sha256:f9e74fda1a25613d7524f2268b5434ad7536b07ef6f957502eb1b439e65240b5`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-08-05T09:00:00+00:00|1997-08-05T09:00:00Z","1997-08-17T09:00:00+00:00|1997-08-17T09:00:00Z","1997-08-19T09:00:00+00:00|1997-08-19T09:00:00Z","1997-08-31T09:00:00+00:00|1997-08-31T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-019` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:6cfc2740d95ff9f51e1c2d6fa1f13c6288a1fe4774b55c07f898904df82610a5`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-08-05T09:00:00+00:00|1997-08-05T09:00:00Z","1997-08-10T09:00:00+00:00|1997-08-10T09:00:00Z","1997-08-19T09:00:00+00:00|1997-08-19T09:00:00Z","1997-08-24T09:00:00+00:00|1997-08-24T09:00:00Z"],"type":"occurrences"}`
- `sha256:b8d8b285a14dfc6ff90a42479cce532d64cad1c5de3f6bf47cbca085c34b2989`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-08-05T09:00:00-04:00|1997-08-05T13:00:00Z","1997-08-10T09:00:00-04:00|1997-08-10T13:00:00Z","1997-08-19T09:00:00-04:00|1997-08-19T13:00:00Z","1997-08-24T09:00:00-04:00|1997-08-24T13:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-020` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:5ce4a4706a8bf9a7a38aa38bab72ff96f6776d029e24889432a81e7e8ae44de2`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-05-12T09:00:00+00:00|1997-05-12T09:00:00Z","1998-05-11T09:00:00+00:00|1998-05-11T09:00:00Z","1999-05-17T09:00:00+00:00|1999-05-17T09:00:00Z"],"type":"occurrences"}`
- `sha256:9e726fad6bbdcc67b0a5607b2e04d01ac83b03022db2523df01776a29a5c8dfd`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-05-12T09:00:00-04:00|1997-05-12T13:00:00Z","1998-05-11T09:00:00-04:00|1998-05-11T13:00:00Z","1999-05-17T09:00:00-04:00|1999-05-17T13:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-021` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:b3783958d5ffb1bad913f7cceaf3245a932b445cff17887df583da66f1938aa5`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2027-01-04T09:00:00+00:00|2027-01-04T09:00:00Z","2028-01-03T09:00:00+00:00|2028-01-03T09:00:00Z","2029-01-01T09:00:00+00:00|2029-01-01T09:00:00Z","2029-12-31T09:00:00+00:00|2029-12-31T09:00:00Z"],"type":"occurrences"}`
- `sha256:d12848137716ae533d4e89dd98c931bbd46057848ebaedc2068b3f392fcfb89d`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2027-01-04T09:00:00-05:00|2027-01-04T14:00:00Z","2028-01-03T09:00:00-05:00|2028-01-03T14:00:00Z","2029-01-01T09:00:00-05:00|2029-01-01T14:00:00Z","2029-12-31T09:00:00-05:00|2029-12-31T14:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-022` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:442f6329a2535119b51734119a8e0968b7663e519f810b384814dd2da8924830`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-12-28T09:00:00+00:00|2026-12-28T09:00:00Z","2032-12-27T09:00:00+00:00|2032-12-27T09:00:00Z","2037-12-28T09:00:00+00:00|2037-12-28T09:00:00Z"],"type":"occurrences"}`
- `sha256:b933ce1814751839dfd54f4783a23274663fd28aba1715f6bf69c3bfefb25413`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-12-28T09:00:00-05:00|2026-12-28T14:00:00Z","2032-12-27T09:00:00-05:00|2032-12-27T14:00:00Z","2037-12-28T09:00:00-05:00|2037-12-28T14:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-023` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.byweekno_wkst`.

- `sha256:7a993d15a44e5307177b04586d06d639ec4d69f87240af04aa61f7915e198d13`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: recorded_unscored=3. Matched cases: none. Answer: `{"occurrences":["2026-01-04T09:00:00-05:00|2026-01-04T14:00:00Z","2027-01-03T09:00:00-05:00|2027-01-03T14:00:00Z","2028-01-02T09:00:00-05:00|2028-01-02T14:00:00Z"],"type":"occurrences"}`
- `sha256:81a13ccc32f9f22a602eafc10d6fdfb69c760f19169683ed2386e2e54d9c872f`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: recorded_unscored=2. Matched cases: none. Answer: `{"occurrences":["2026-01-04T09:00:00+00:00|2026-01-04T09:00:00Z","2027-01-03T09:00:00+00:00|2027-01-03T09:00:00Z","2028-01-02T09:00:00+00:00|2028-01-02T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-024` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 1 build(s): php.php-rrule. Verdicts: conformant=1. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 4 build(s): go.rrule-go, javascript.rrule-js, python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"accepted"}`

### `RRULE-BY-025` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 1 build(s): php.php-rrule. Verdicts: conformant=1. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 4 build(s): go.rrule-go, javascript.rrule-js, python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"accepted"}`

### `RRULE-BY-026` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.byday_ordinal_scope`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 1 build(s): php.php-rrule. Verdicts: recorded_unscored=1. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:9d618fb92a708381628b5351f699f37b50ae839f99d31350a3f77e6feb118010`: 4 build(s): go.rrule-go, javascript.rrule-js, python.dateutil.system, python.dateutil.vendored. Verdicts: recorded_unscored=4. Matched cases: none. Answer: `{"occurrences":[],"type":"occurrences"}`

### `RRULE-BY-027` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.note2`.

- `sha256:58789e686155c66f278a903a0a57e79d1d63d79b2480029d358b200bcaeb4e0d`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-15T09:00:00+00:00|2026-03-15T09:00:00Z","2026-04-15T09:00:00+00:00|2026-04-15T09:00:00Z","2026-05-15T09:00:00+00:00|2026-05-15T09:00:00Z","2026-06-15T09:00:00+00:00|2026-06-15T09:00:00Z"],"type":"occurrences"}`
- `sha256:bd44939ead5778ef5f401f387da919ab8ee24cde338255aae30287e82c9586c9`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant_admissible=3. Matched cases: expand. Answer: `{"occurrences":["2026-03-15T09:00:00-04:00|2026-03-15T13:00:00Z","2026-04-15T09:00:00-04:00|2026-04-15T13:00:00Z","2026-05-15T09:00:00-04:00|2026-05-15T13:00:00Z","2026-06-15T09:00:00-04:00|2026-06-15T13:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-028` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:49dafcf49fdcb1d46f24465eb1a85fb31ebb5dbdef5fe22cc0cccd1ab195230c`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-15T09:00:00+00:00|2026-03-15T09:00:00Z","2026-06-15T09:00:00+00:00|2026-06-15T09:00:00Z","2026-09-15T09:00:00+00:00|2026-09-15T09:00:00Z","2026-12-15T09:00:00+00:00|2026-12-15T09:00:00Z"],"type":"occurrences"}`
- `sha256:a9664abe026b0ee5658230ab10c74200c8ac1eeb63236269c3629cb44b34482e`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-03-15T09:00:00-04:00|2026-03-15T13:00:00Z","2026-06-15T09:00:00-04:00|2026-06-15T13:00:00Z","2026-09-15T09:00:00-04:00|2026-09-15T13:00:00Z","2026-12-15T09:00:00-05:00|2026-12-15T14:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-029` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:078a1ba671e7681627704867769ff5b1273f23849123bc9a8b1c08ee690e007f`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-01T09:00:00+00:00|2026-01-01T09:00:00Z","2026-01-01T17:00:00+00:00|2026-01-01T17:00:00Z","2026-01-02T09:00:00+00:00|2026-01-02T09:00:00Z","2026-01-02T17:00:00+00:00|2026-01-02T17:00:00Z"],"type":"occurrences"}`
- `sha256:79173b42b0b101d0c5aa1604e5e57961fd3d2bc6a39680ea919c179266382c54`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-01-01T09:00:00-05:00|2026-01-01T14:00:00Z","2026-01-01T17:00:00-05:00|2026-01-01T22:00:00Z","2026-01-02T09:00:00-05:00|2026-01-02T14:00:00Z","2026-01-02T17:00:00-05:00|2026-01-02T22:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-030` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:db36a312edc8384ee91e3beda6d5636ca7faada0b1ada1063703b6468c5b46ba`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1996-11-05T09:00:00-05:00|1996-11-05T14:00:00Z","2000-11-07T09:00:00-05:00|2000-11-07T14:00:00Z","2004-11-02T09:00:00-05:00|2004-11-02T14:00:00Z"],"type":"occurrences"}`
- `sha256:f5c6eccf71ea25d1ded432f986906ab4b0b2da9d5de446fa3d7ac8cea48320bf`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1996-11-05T09:00:00+00:00|1996-11-05T09:00:00Z","2000-11-07T09:00:00+00:00|2000-11-07T09:00:00Z","2004-11-02T09:00:00+00:00|2004-11-02T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-031` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:8a18bbda3d9b91d45a263249df34bcc9e3e9e16ecfb94e13d7176e21174fe4c7`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2007-01-15T09:00:00-05:00|2007-01-15T14:00:00Z","2007-01-30T09:00:00-05:00|2007-01-30T14:00:00Z","2007-02-15T09:00:00-05:00|2007-02-15T14:00:00Z","2007-03-15T09:00:00-04:00|2007-03-15T13:00:00Z","2007-03-30T09:00:00-04:00|2007-03-30T13:00:00Z"],"type":"occurrences"}`
- `sha256:964a61c4804748e2f84508c8f644d2239b0227d362bde6eed71541cd345a7cb9`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2007-01-15T09:00:00+00:00|2007-01-15T09:00:00Z","2007-01-30T09:00:00+00:00|2007-01-30T09:00:00Z","2007-02-15T09:00:00+00:00|2007-02-15T09:00:00Z","2007-03-15T09:00:00+00:00|2007-03-15T09:00:00Z","2007-03-30T09:00:00+00:00|2007-03-30T09:00:00Z"],"type":"occurrences"}`

### `RRULE-BY-032` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 3 build(s): javascript.rrule-js, python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"type":"accepted"}`

### `RRULE-CORE-001` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:85f5a8ec7eaa9207637f952eeea30f5524f3bad3bb45850fc222dae179cda3b1`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00+00:00|1997-09-02T09:00:00Z","1997-09-03T09:00:00+00:00|1997-09-03T09:00:00Z","1997-09-04T09:00:00+00:00|1997-09-04T09:00:00Z","1997-09-05T09:00:00+00:00|1997-09-05T09:00:00Z","1997-09-06T09:00:00+00:00|1997-09-06T09:00:00Z","1997-09-07T09:00:00+00:00|1997-09-07T09:00:00Z","1997-09-08T09:00:00+00:00|1997-09-08T09:00:00Z","1997-09-09T09:00:00+00:00|1997-09-09T09:00:00Z","1997-09-10T09:00:00+00:00|1997-09-10T09:00:00Z","1997-09-11T09:00:00+00:00|1997-09-11T09:00:00Z"],"type":"occurrences"}`
- `sha256:c7754eb63c9c863f7de64b3622b66b2c75f836f8788a505c1afe8ccfa51ab8b8`: 5 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule, python.pandas.system, python.pandas.vendored. Verdicts: conformant=5. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z","1997-09-03T09:00:00-04:00|1997-09-03T13:00:00Z","1997-09-04T09:00:00-04:00|1997-09-04T13:00:00Z","1997-09-05T09:00:00-04:00|1997-09-05T13:00:00Z","1997-09-06T09:00:00-04:00|1997-09-06T13:00:00Z","1997-09-07T09:00:00-04:00|1997-09-07T13:00:00Z","1997-09-08T09:00:00-04:00|1997-09-08T13:00:00Z","1997-09-09T09:00:00-04:00|1997-09-09T13:00:00Z","1997-09-10T09:00:00-04:00|1997-09-10T13:00:00Z","1997-09-11T09:00:00-04:00|1997-09-11T13:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-002` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:dc7e80316007f34a2ff6724abda536dc903a11ef4333b02d60a7c015ea4727c7`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00+00:00|1997-09-02T09:00:00Z"],"type":"occurrences"}`
- `sha256:eb76a887cc9ea373d4fb796c06646baae68550cbb2363607501467d5e5c27a07`: 5 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule, python.pandas.system, python.pandas.vendored. Verdicts: conformant=5. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-003` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.dtstart_emission`.

- `sha256:0ad4c604614ed42dfc935bc5b93a22d71f25a15624186abe7f3e857a1951f4b5`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant_admissible=3. Matched cases: rule-only. Answer: `{"occurrences":["1998-02-13T09:00:00-05:00|1998-02-13T14:00:00Z","1998-03-13T09:00:00-05:00|1998-03-13T14:00:00Z","1998-11-13T09:00:00-05:00|1998-11-13T14:00:00Z","1999-08-13T09:00:00-04:00|1999-08-13T13:00:00Z"],"type":"occurrences"}`
- `sha256:16c1c9d502f5765b38aa15e79b22fe9ed2089ec728cfade3f3fd3498c718a7e3`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1998-02-13T09:00:00+00:00|1998-02-13T09:00:00Z","1998-03-13T09:00:00+00:00|1998-03-13T09:00:00Z","1998-11-13T09:00:00+00:00|1998-11-13T09:00:00Z","1999-08-13T09:00:00+00:00|1999-08-13T09:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-004` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:ed8b7161f352643a0d56db29ae16171e8b4bcd1c7981760cf3ff79ec284ade69`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1998-02-13T09:00:00-05:00|1998-02-13T14:00:00Z","1998-03-13T09:00:00-05:00|1998-03-13T14:00:00Z","1998-11-13T09:00:00-05:00|1998-11-13T14:00:00Z","1999-08-13T09:00:00-04:00|1999-08-13T13:00:00Z","2000-10-13T09:00:00-04:00|2000-10-13T13:00:00Z"],"type":"occurrences"}`
- `sha256:f95ef24a80248d88de5942e329be237c0c7ac5726951a5103edb865cc23da821`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1998-02-13T09:00:00+00:00|1998-02-13T09:00:00Z","1998-03-13T09:00:00+00:00|1998-03-13T09:00:00Z","1998-11-13T09:00:00+00:00|1998-11-13T09:00:00Z","1999-08-13T09:00:00+00:00|1999-08-13T09:00:00Z","2000-10-13T09:00:00+00:00|2000-10-13T09:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-005` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:6040fdfeeb7b8190c82fafe51c13398f002cf00601fc505fd8fae1851432d499`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z","1997-09-03T09:00:00-04:00|1997-09-03T13:00:00Z","1997-09-04T09:00:00-04:00|1997-09-04T13:00:00Z"],"type":"occurrences"}`
- `sha256:bb51274212626d69ba15d7476156c7b17e787a6abecdf059d2cf7bfa4136a318`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00+00:00|1997-09-02T09:00:00Z","1997-09-03T09:00:00+00:00|1997-09-03T09:00:00Z","1997-09-04T09:00:00+00:00|1997-09-04T09:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-006` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:6040fdfeeb7b8190c82fafe51c13398f002cf00601fc505fd8fae1851432d499`: 1 build(s): javascript.rrule-js. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z","1997-09-03T09:00:00-04:00|1997-09-03T13:00:00Z","1997-09-04T09:00:00-04:00|1997-09-04T13:00:00Z"],"type":"occurrences"}`
- `sha256:74c8bfe2832ec38055a51b09334a6f3b90ebd2d3a30ceaa38c09c91f3433ccef`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z","1997-09-03T09:00:00-04:00|1997-09-03T13:00:00Z"],"type":"occurrences"}`
- `sha256:bb51274212626d69ba15d7476156c7b17e787a6abecdf059d2cf7bfa4136a318`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00+00:00|1997-09-02T09:00:00Z","1997-09-03T09:00:00+00:00|1997-09-03T09:00:00Z","1997-09-04T09:00:00+00:00|1997-09-04T09:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-007` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:8b23d10db8f10315375de8840a2d1641518b21eaa35e915aaf077b8f6cfb9ac9`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z","1997-09-02T12:00:00-04:00|1997-09-02T16:00:00Z","1997-09-02T15:00:00-04:00|1997-09-02T19:00:00Z"],"type":"occurrences"}`
- `sha256:94f02d8d92729e3fd78044f7e6821b5fdd7c119b7a584ae2cc21a321170463ad`: 1 build(s): javascript.rrule-js. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z","1997-09-02T12:00:00-04:00|1997-09-02T16:00:00Z","1997-09-02T15:00:00-04:00|1997-09-02T19:00:00Z","1997-09-02T18:00:00-04:00|1997-09-02T22:00:00Z","1997-09-02T21:00:00-04:00|1997-09-03T01:00:00Z"],"type":"occurrences"}`
- `sha256:c9b4ff20b8fab0daf323ef577cc3044dc0be36412bb9990933f8de54b9b4101b`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00+00:00|1997-09-02T09:00:00Z","1997-09-02T12:00:00+00:00|1997-09-02T12:00:00Z","1997-09-02T15:00:00+00:00|1997-09-02T15:00:00Z","1997-09-02T18:00:00+00:00|1997-09-02T18:00:00Z","1997-09-02T21:00:00+00:00|1997-09-02T21:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-008` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:8b23d10db8f10315375de8840a2d1641518b21eaa35e915aaf077b8f6cfb9ac9`: 1 build(s): javascript.rrule-js. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z","1997-09-02T12:00:00-04:00|1997-09-02T16:00:00Z","1997-09-02T15:00:00-04:00|1997-09-02T19:00:00Z"],"type":"occurrences"}`
- `sha256:b4b816eb1e1e3ea21448586263ddbc8f3406784d5056e005d975d48415420c5a`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z","1997-09-02T12:00:00-04:00|1997-09-02T16:00:00Z"],"type":"occurrences"}`
- `sha256:eabda666a199100ea939466b70a0317d037cd920794b923cfc0fe49694edb170`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00+00:00|1997-09-02T09:00:00Z","1997-09-02T12:00:00+00:00|1997-09-02T12:00:00Z","1997-09-02T15:00:00+00:00|1997-09-02T15:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-010` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 3 build(s): php.php-rrule, python.dateutil.system, python.dateutil.vendored. Verdicts: conformant=3. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 2 build(s): go.rrule-go, javascript.rrule-js. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"accepted"}`

### `RRULE-CORE-011` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 1 build(s): php.php-rrule. Verdicts: conformant=1. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 4 build(s): go.rrule-go, javascript.rrule-js, python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"accepted"}`

### `RRULE-CORE-012` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:dd476ac4158554d2a5469c1ff0164af66c7e5b2354e12e00700536b3a810d6a9`: 5 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule, python.pandas.system, python.pandas.vendored. Verdicts: conformant=5. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z","1997-09-12T09:00:00-04:00|1997-09-12T13:00:00Z","1997-09-22T09:00:00-04:00|1997-09-22T13:00:00Z","1997-10-02T09:00:00-04:00|1997-10-02T13:00:00Z","1997-10-12T09:00:00-04:00|1997-10-12T13:00:00Z"],"type":"occurrences"}`
- `sha256:e5ae548e471820d356a697f860eb62b8b68982ff05e9bdfbb4e9617674958f8b`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00+00:00|1997-09-02T09:00:00Z","1997-09-12T09:00:00+00:00|1997-09-12T09:00:00Z","1997-09-22T09:00:00+00:00|1997-09-22T09:00:00Z","1997-10-02T09:00:00+00:00|1997-10-02T09:00:00Z","1997-10-12T09:00:00+00:00|1997-10-12T09:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-013` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `rrule.truncation`.

- `sha256:0b66fd406cc9f00f904a62bbca122c70506f8c5c03a7bc24b7bfa78b236b5af6`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00-04:00|1997-09-02T13:00:00Z","1997-09-03T09:00:00-04:00|1997-09-03T13:00:00Z","1997-09-04T09:00:00-04:00|1997-09-04T13:00:00Z","1997-09-05T09:00:00-04:00|1997-09-05T13:00:00Z","1997-09-06T09:00:00-04:00|1997-09-06T13:00:00Z"],"type":"occurrences"}`
- `sha256:3bcc344a719001a162d43ac9224f6058246ab977319d756f3035691810e2e838`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00+00:00|1997-09-02T09:00:00Z","1997-09-03T09:00:00+00:00|1997-09-03T09:00:00Z","1997-09-04T09:00:00+00:00|1997-09-04T09:00:00Z","1997-09-05T09:00:00+00:00|1997-09-05T09:00:00Z","1997-09-06T09:00:00+00:00|1997-09-06T09:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-014` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `rrule.range_inclusivity`.

- `sha256:7e4e8c1f305ef2a1435ef7a5e8b589af9fc98e4be570e669bc4ae88517d8e579`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["1997-09-05T09:00:00+00:00|1997-09-05T09:00:00Z"],"type":"occurrences"}`
- `sha256:8a0ca849ce5cea1370d6dbe80b787787deca5961e6cb06f4bb083844937de506`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"occurrences":["1997-09-05T09:00:00-04:00|1997-09-05T13:00:00Z"],"type":"occurrences"}`

### `RRULE-CORE-015` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 6 build(s): go.rrule-go, php.php-rrule, python.dateutil.system, python.dateutil.vendored, python.pandas.system, python.pandas.vendored. Verdicts: conformant=6. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 1 build(s): javascript.rrule-js. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"type":"accepted"}`

### `RRULE-CORE-016` — `normative violation`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 3 build(s): php.php-rrule, python.pandas.system, python.pandas.vendored. Verdicts: conformant=3. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 4 build(s): go.rrule-go, javascript.rrule-js, python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"accepted"}`

### `RRULE-CORE-017` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.count_zero`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 1 build(s): php.php-rrule. Verdicts: conformant_admissible=1. Matched cases: reject. Answer: `{"type":"rejection"}`
- `sha256:9d618fb92a708381628b5351f699f37b50ae839f99d31350a3f77e6feb118010`: 5 build(s): javascript.rrule-js, python.dateutil.system, python.dateutil.vendored, python.pandas.system, python.pandas.vendored. Verdicts: conformant_admissible=5. Matched cases: empty. Answer: `{"occurrences":[],"type":"occurrences"}`
- `sha256:aadf3f6149c5dd95ceb7a63cf63b7238af7242048d71f4cbbe43ed5b75a38752`: 1 build(s): go.rrule-go. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["1997-09-02T09:00:00","1997-09-03T09:00:00","1997-09-04T09:00:00"],"type":"occurrences"}`

### `RRULE-DST-001` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): python.pandas.system, python.pandas.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:21478315561559700ef0e90afad5f0ce951ff74d9460bed071b5ce42d9611f27`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-06T02:30:00+00:00|2026-03-06T02:30:00Z","2026-03-07T02:30:00+00:00|2026-03-07T02:30:00Z","2026-03-08T02:30:00+00:00|2026-03-08T02:30:00Z","2026-03-09T02:30:00+00:00|2026-03-09T02:30:00Z"],"type":"occurrences"}`
- `sha256:3ced20e5aa7be7bacb2ae5659b19ed9c3f3ed4d633e956f866cef1b59f08fa2f`: 2 build(s): javascript.rrule-js, php.php-rrule. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-06T02:30:00-05:00|2026-03-06T07:30:00Z","2026-03-07T02:30:00-05:00|2026-03-07T07:30:00Z","2026-03-08T03:30:00-04:00|2026-03-08T07:30:00Z","2026-03-09T02:30:00-04:00|2026-03-09T06:30:00Z"],"type":"occurrences"}`
- `sha256:d1327f76e887bce886e1bdac133117021d547357feccc2d28fb1ec24cbc6c4d3`: 1 build(s): go.rrule-go. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-03-06T02:30:00-05:00|2026-03-06T07:30:00Z","2026-03-07T02:30:00-05:00|2026-03-07T07:30:00Z","2026-03-08T01:30:00-05:00|2026-03-08T06:30:00Z","2026-03-09T02:30:00-04:00|2026-03-09T06:30:00Z"],"type":"occurrences"}`

### `RRULE-DST-002` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): python.pandas.system, python.pandas.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:1104185e5b52e977ddf6284806f2ff33eb39c87d6e5ea8bb066ba5a4553bd2ff`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-10-30T01:30:00+00:00|2026-10-30T01:30:00Z","2026-10-31T01:30:00+00:00|2026-10-31T01:30:00Z","2026-11-01T01:30:00+00:00|2026-11-01T01:30:00Z","2026-11-02T01:30:00+00:00|2026-11-02T01:30:00Z"],"type":"occurrences"}`
- `sha256:551330456368db651b30d1805b942fb8a9588fbb231b68dc72d0175bb900ff05`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-10-30T01:30:00-04:00|2026-10-30T05:30:00Z","2026-10-31T01:30:00-04:00|2026-10-31T05:30:00Z","2026-11-01T01:30:00-04:00|2026-11-01T05:30:00Z","2026-11-02T01:30:00-05:00|2026-11-02T06:30:00Z"],"type":"occurrences"}`

### `RRULE-DST-003` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:2cecd2b0f80cc6c27114ceba4854d58beee583a28d415ba21fafeb8941e2e845`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-01T09:00:00+00:00|2026-03-01T09:00:00Z","2026-03-08T09:00:00+00:00|2026-03-08T09:00:00Z","2026-03-15T09:00:00+00:00|2026-03-15T09:00:00Z"],"type":"occurrences"}`
- `sha256:5cdb51ed840a7003a321bc5e9a11bf0351d3a247390bcca3d9d7710c1bb1f374`: 5 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule, python.pandas.system, python.pandas.vendored. Verdicts: conformant=5. Matched cases: none. Answer: `{"occurrences":["2026-03-01T09:00:00-05:00|2026-03-01T14:00:00Z","2026-03-08T09:00:00-04:00|2026-03-08T13:00:00Z","2026-03-15T09:00:00-04:00|2026-03-15T13:00:00Z"],"type":"occurrences"}`

### `RRULE-DST-004` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): python.pandas.system, python.pandas.vendored. Verdicts: recorded_unscored=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:12485b7644ab39fcd4c0a54ad5054b97dc43c70ae649885ec134787588b29c33`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: recorded_unscored=2. Matched cases: none. Answer: `{"occurrences":["2026-09-19T02:15:00+00:00|2026-09-19T02:15:00Z","2026-09-26T02:15:00+00:00|2026-09-26T02:15:00Z","2026-10-03T02:15:00+00:00|2026-10-03T02:15:00Z","2026-10-10T02:15:00+00:00|2026-10-10T02:15:00Z"],"type":"occurrences"}`
- `sha256:fd0342523652ae0c0f233e9b91e4966e93e4d7b9ff74bd31f13a2f2799a0c94d`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: recorded_unscored=3. Matched cases: none. Answer: `{"occurrences":["2026-09-19T02:15:00+10:30|2026-09-18T15:45:00Z","2026-09-26T02:15:00+10:30|2026-09-25T15:45:00Z","2026-10-03T02:15:00+10:30|2026-10-02T15:45:00Z","2026-10-10T02:15:00+11:00|2026-10-09T15:15:00Z"],"type":"occurrences"}`

### `RRULE-DST-005` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.gap`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): python.pandas.system, python.pandas.vendored. Verdicts: recorded_unscored=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:49be21bd89e83e585b0c6b06fe89209e9f1509aff48c00e9c54dcbff24957fb2`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: recorded_unscored=2. Matched cases: none. Answer: `{"occurrences":["2026-03-27T01:30:00+00:00|2026-03-27T01:30:00Z","2026-03-28T01:30:00+00:00|2026-03-28T01:30:00Z","2026-03-29T03:30:00+02:00|2026-03-29T01:30:00Z","2026-03-30T01:30:00+02:00|2026-03-29T23:30:00Z"],"type":"occurrences"}`
- `sha256:8d50bf3d3278e0ddd319a992f389bc2af460913d8904b993532bad8bbde81366`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: recorded_unscored=2. Matched cases: none. Answer: `{"occurrences":["2026-03-27T01:30:00+00:00|2026-03-27T01:30:00Z","2026-03-28T01:30:00+00:00|2026-03-28T01:30:00Z","2026-03-29T01:30:00+00:00|2026-03-29T01:30:00Z","2026-03-30T01:30:00+00:00|2026-03-30T01:30:00Z"],"type":"occurrences"}`
- `sha256:f643a944fb46af6f23f823e209ae968382a42d9d004192a21a21a3d412520830`: 1 build(s): javascript.rrule-js. Verdicts: recorded_unscored=1. Matched cases: none. Answer: `{"occurrences":["2026-03-27T01:30:00+00:00|2026-03-27T01:30:00Z","2026-03-28T01:30:00+00:00|2026-03-28T01:30:00Z","2026-03-28T23:30:00+00:00|2026-03-28T23:30:00Z","2026-03-30T01:30:00+02:00|2026-03-29T23:30:00Z"],"type":"occurrences"}`

### `RRULE-DST-006` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.gap`.

- `sha256:2125cc765b193182e13079e5a58047bd399a3972b6f55ca879bd5f4a787d883d`: 1 build(s): php.php-rrule. Verdicts: recorded_unscored=1. Matched cases: none. Answer: `{"occurrences":["2011-10-30T12:00:00-10:00|2011-10-30T22:00:00Z","2011-11-30T12:00:00-10:00|2011-11-30T22:00:00Z","2011-12-31T12:00:00+14:00|2011-12-30T22:00:00Z","2012-01-30T12:00:00+14:00|2012-01-29T22:00:00Z"],"type":"occurrences"}`
- `sha256:5c50ff3b1dfb6469879361f7fcc7de60d3c30e339a77de3ff9932cb3068ceeea`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: recorded_unscored=2. Matched cases: none. Answer: `{"occurrences":["2011-10-30T12:00:00+00:00|2011-10-30T12:00:00Z","2011-11-30T12:00:00+00:00|2011-11-30T12:00:00Z","2011-12-30T12:00:00+00:00|2011-12-30T12:00:00Z","2012-01-30T12:00:00+00:00|2012-01-30T12:00:00Z"],"type":"occurrences"}`
- `sha256:b5cf27adf33054dcba649e46c96d66848d032e91823ebd60fe63a1aaf53603b0`: 2 build(s): go.rrule-go, javascript.rrule-js. Verdicts: recorded_unscored=2. Matched cases: none. Answer: `{"occurrences":["2011-10-30T12:00:00-10:00|2011-10-30T22:00:00Z","2011-11-30T12:00:00-10:00|2011-11-30T22:00:00Z","2011-12-29T12:00:00-10:00|2011-12-29T22:00:00Z","2012-01-30T12:00:00+14:00|2012-01-29T22:00:00Z"],"type":"occurrences"}`

### `RRULE-DST-007` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:cb5434ba7521bff76997256694c2c8087abc7f56b5663bae4d56723aaf09dd57`: 5 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule, python.dateutil.system, python.dateutil.vendored. Verdicts: conformant=5. Matched cases: none. Answer: `{"occurrences":["2026-03-06T07:30:00+00:00|2026-03-06T07:30:00Z","2026-03-07T07:30:00+00:00|2026-03-07T07:30:00Z","2026-03-08T07:30:00+00:00|2026-03-08T07:30:00Z","2026-03-09T07:30:00+00:00|2026-03-09T07:30:00Z"],"type":"occurrences"}`
- `sha256:cd657212123dcce967b2b719db3d0e18dd9fa1b038ce5a162ac7df954b5709cd`: 2 build(s): python.pandas.system, python.pandas.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-06T07:30:00","2026-03-07T07:30:00","2026-03-08T07:30:00","2026-03-09T07:30:00"],"type":"occurrences"}`

### `RRULE-DST-009` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:021d5bb960a1befda956c27d05b6f9f44d078feee7da881ea0e264a29a4d8c51`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-11-01T00:00:00+00:00|2026-11-01T00:00:00Z","2026-11-01T01:00:00+00:00|2026-11-01T01:00:00Z","2026-11-01T02:00:00+00:00|2026-11-01T02:00:00Z","2026-11-01T03:00:00+00:00|2026-11-01T03:00:00Z","2026-11-01T04:00:00+00:00|2026-11-01T04:00:00Z"],"type":"occurrences"}`
- `sha256:4062a305ffbdcf1ce3cdef69eb9281179f61e4f2336191f13e3643cf274278ce`: 3 build(s): javascript.rrule-js, python.pandas.system, python.pandas.vendored. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-11-01T00:00:00-04:00|2026-11-01T04:00:00Z","2026-11-01T01:00:00-04:00|2026-11-01T05:00:00Z","2026-11-01T01:00:00-05:00|2026-11-01T06:00:00Z","2026-11-01T02:00:00-05:00|2026-11-01T07:00:00Z","2026-11-01T03:00:00-05:00|2026-11-01T08:00:00Z"],"type":"occurrences"}`
- `sha256:c8c961c14d3743fae2f0601862e083bb1e76d6edcb47906f4baf546ea63d42b3`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-11-01T00:00:00-04:00|2026-11-01T04:00:00Z","2026-11-01T01:00:00-04:00|2026-11-01T05:00:00Z","2026-11-01T02:00:00-05:00|2026-11-01T07:00:00Z","2026-11-01T03:00:00-05:00|2026-11-01T08:00:00Z","2026-11-01T04:00:00-05:00|2026-11-01T09:00:00Z"],"type":"occurrences"}`

### `RRULE-DST-010` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:0e6b958e100d5b90f735cb14cc68479c8904973ab742d19f2dda6d07fee50cba`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-08T00:00:00-05:00|2026-03-08T05:00:00Z","2026-03-08T01:00:00-05:00|2026-03-08T06:00:00Z","2026-03-08T03:00:00-04:00|2026-03-08T07:00:00Z","2026-03-08T04:00:00-04:00|2026-03-08T08:00:00Z"],"type":"occurrences"}`
- `sha256:586fdf48f4df3aa0cf39eaf741095f9ce07d12166222083acb1a59e1792a7480`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-03-08T00:00:00+00:00|2026-03-08T00:00:00Z","2026-03-08T01:00:00+00:00|2026-03-08T01:00:00Z","2026-03-08T02:00:00+00:00|2026-03-08T02:00:00Z","2026-03-08T03:00:00+00:00|2026-03-08T03:00:00Z","2026-03-08T04:00:00+00:00|2026-03-08T04:00:00Z"],"type":"occurrences"}`
- `sha256:6d5ac2f0a645a9700a952a0b0639b6cc4122ca5540a28d016f2d6bd46a5cfb94`: 3 build(s): javascript.rrule-js, python.pandas.system, python.pandas.vendored. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-03-08T00:00:00-05:00|2026-03-08T05:00:00Z","2026-03-08T01:00:00-05:00|2026-03-08T06:00:00Z","2026-03-08T03:00:00-04:00|2026-03-08T07:00:00Z","2026-03-08T04:00:00-04:00|2026-03-08T08:00:00Z","2026-03-08T05:00:00-04:00|2026-03-08T09:00:00Z"],"type":"occurrences"}`

### `RRULE-DST-011` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:033b75f066a67491951f916fdf7844c513ec79628c58b5fa161dd46417225604`: 5 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule, python.pandas.system, python.pandas.vendored. Verdicts: conformant=5. Matched cases: none. Answer: `{"occurrences":["2022-10-27T00:30:00+03:00|2022-10-26T21:30:00Z","2022-10-28T00:30:00+03:00|2022-10-27T21:30:00Z","2022-10-29T00:30:00+03:00|2022-10-28T21:30:00Z","2022-10-30T00:30:00+03:00|2022-10-29T21:30:00Z"],"type":"occurrences"}`
- `sha256:076b42ea23e8e2e4429dbc1af39a87308ecc95df885da87a95ecee1f40d50b12`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2022-10-27T00:30:00+00:00|2022-10-27T00:30:00Z","2022-10-28T00:30:00+00:00|2022-10-28T00:30:00Z","2022-10-29T00:30:00+00:00|2022-10-29T00:30:00Z","2022-10-30T00:30:00+00:00|2022-10-30T00:30:00Z"],"type":"occurrences"}`

### `RRULE-DST-012` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:033b75f066a67491951f916fdf7844c513ec79628c58b5fa161dd46417225604`: 5 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule, python.pandas.system, python.pandas.vendored. Verdicts: conformant=5. Matched cases: none. Answer: `{"occurrences":["2022-10-27T00:30:00+03:00|2022-10-26T21:30:00Z","2022-10-28T00:30:00+03:00|2022-10-27T21:30:00Z","2022-10-29T00:30:00+03:00|2022-10-28T21:30:00Z","2022-10-30T00:30:00+03:00|2022-10-29T21:30:00Z"],"type":"occurrences"}`
- `sha256:076b42ea23e8e2e4429dbc1af39a87308ecc95df885da87a95ecee1f40d50b12`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2022-10-27T00:30:00+00:00|2022-10-27T00:30:00Z","2022-10-28T00:30:00+00:00|2022-10-28T00:30:00Z","2022-10-29T00:30:00+00:00|2022-10-29T00:30:00Z","2022-10-30T00:30:00+00:00|2022-10-30T00:30:00Z"],"type":"occurrences"}`

### `RRULE-SET-001` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:54dc09725e928675ee8a09c03c93e87a57a16bb761feeb5e1bde7ad9c06e50c0`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00+00:00|2026-01-05T09:00:00Z","2026-01-06T09:00:00+00:00|2026-01-06T09:00:00Z","2026-01-08T09:00:00+00:00|2026-01-08T09:00:00Z","2026-01-09T09:00:00+00:00|2026-01-09T09:00:00Z"],"type":"occurrences"}`
- `sha256:d5a866ff824c63bd57d58eeb6ff021bb8d266fd700c772e5258aa82b0d27d393`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-06T09:00:00-05:00|2026-01-06T14:00:00Z","2026-01-08T09:00:00-05:00|2026-01-08T14:00:00Z","2026-01-09T09:00:00-05:00|2026-01-09T14:00:00Z"],"type":"occurrences"}`

### `RRULE-SET-002` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:83452cef317b992f22bb99ea4f4a4dfaaa98826186aefd3b23a85b6313849b9c`: 1 build(s): javascript.rrule-js. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-07T14:00:00-05:00|2026-01-07T19:00:00Z","2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-12T09:00:00-05:00|2026-01-12T14:00:00Z","2026-01-19T09:00:00-05:00|2026-01-19T14:00:00Z"],"type":"occurrences"}`
- `sha256:ef59aa9a5515a394359fc624b521ba6d99b966f0aeb7dc5e4285f8dd0a8aa664`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-07T14:00:00-05:00|2026-01-07T19:00:00Z","2026-01-12T09:00:00-05:00|2026-01-12T14:00:00Z","2026-01-19T09:00:00-05:00|2026-01-19T14:00:00Z"],"type":"occurrences"}`

### `RRULE-SET-003` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:7007ec2ab690ff5c7bb5fcd54e1309b2cf36638e52fe5707b0cb0f9ed1b8dee9`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-12T09:00:00-05:00|2026-01-12T14:00:00Z"],"type":"occurrences"}`

### `RRULE-SET-004` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.exdate_value_type`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: conformant_admissible=2. Matched cases: reject. Answer: `{"type":"rejection"}`
- `sha256:f9c931f98d922dd578aadbe2b38dae5612a0a39b7e690321310ae7878f030b5b`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant_admissible=3. Matched cases: exclude-midnight-only. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-05T15:00:00-05:00|2026-01-05T20:00:00Z","2026-01-05T21:00:00-05:00|2026-01-06T02:00:00Z","2026-01-06T03:00:00-05:00|2026-01-06T08:00:00Z","2026-01-06T09:00:00-05:00|2026-01-06T14:00:00Z","2026-01-06T15:00:00-05:00|2026-01-06T20:00:00Z","2026-01-06T21:00:00-05:00|2026-01-07T02:00:00Z","2026-01-07T03:00:00-05:00|2026-01-07T08:00:00Z"],"type":"occurrences"}`

### `RRULE-SET-005` — `documented policy difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `rrule.exdate_unmatched`.

- `sha256:61ba887059e296a5cbdf8b5e27150ccd9fdd133c98bc8ee74b5dbbbf61e86cb0`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-06T09:00:00-05:00|2026-01-06T14:00:00Z","2026-01-07T09:00:00-05:00|2026-01-07T14:00:00Z"],"type":"occurrences"}`
- `sha256:f1974b611c8fda06871c5040ee77696a3521f5b025cd5d3cccb5560c2313dc79`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00+00:00|2026-01-05T09:00:00Z","2026-01-06T09:00:00+00:00|2026-01-06T09:00:00Z","2026-01-07T09:00:00+00:00|2026-01-07T09:00:00Z"],"type":"occurrences"}`

### `RRULE-SET-006` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.exdate_matching`.

- `sha256:61ba887059e296a5cbdf8b5e27150ccd9fdd133c98bc8ee74b5dbbbf61e86cb0`: 1 build(s): javascript.rrule-js. Verdicts: conformant_admissible=1. Matched cases: wall-time-match. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-06T09:00:00-05:00|2026-01-06T14:00:00Z","2026-01-07T09:00:00-05:00|2026-01-07T14:00:00Z"],"type":"occurrences"}`
- `sha256:80a4ad22148c854941df224db2456150d8a934da24f777b7baa4dc26bc01d7a3`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: conformant_admissible=2. Matched cases: instant-match. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-07T09:00:00-05:00|2026-01-07T14:00:00Z"],"type":"occurrences"}`
- `sha256:f1974b611c8fda06871c5040ee77696a3521f5b025cd5d3cccb5560c2313dc79`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00+00:00|2026-01-05T09:00:00Z","2026-01-06T09:00:00+00:00|2026-01-06T09:00:00Z","2026-01-07T09:00:00+00:00|2026-01-07T09:00:00Z"],"type":"occurrences"}`

### `RRULE-SET-007` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:58283ff358776019f4130ab75e5f89572758cb05e77c598833aa03e895c7f514`: 1 build(s): javascript.rrule-js. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-06T09:00:00-05:00|2026-01-06T14:00:00Z","2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-07T09:00:00-05:00|2026-01-07T14:00:00Z"],"type":"occurrences"}`
- `sha256:61ba887059e296a5cbdf8b5e27150ccd9fdd133c98bc8ee74b5dbbbf61e86cb0`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-06T09:00:00-05:00|2026-01-06T14:00:00Z","2026-01-07T09:00:00-05:00|2026-01-07T14:00:00Z"],"type":"occurrences"}`

### `RRULE-SET-008` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.multiple_rrule`.

- `sha256:062285c2438618973fc17e96305c6dd99b4b342d332f0be9c087f01edde5e659`: 1 build(s): php.php-rrule. Verdicts: conformant_admissible=1. Matched cases: union. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-07T09:00:00-05:00|2026-01-07T14:00:00Z","2026-01-12T09:00:00-05:00|2026-01-12T14:00:00Z","2026-01-14T09:00:00-05:00|2026-01-14T14:00:00Z"],"type":"occurrences"}`
- `sha256:9fd014492a147740c7cc77a344df04973d1f52f2787855a01dd4037622dbad04`: 1 build(s): javascript.rrule-js. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-12T09:00:00-05:00|2026-01-12T14:00:00Z","2026-01-07T09:00:00-05:00|2026-01-07T14:00:00Z","2026-01-14T09:00:00-05:00|2026-01-14T14:00:00Z"],"type":"occurrences"}`
- `sha256:b7000cc85a4e83791fcc6ecd2b98de140502b99c150c659dc31950c00459a7b1`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00+00:00|2026-01-05T09:00:00Z","2026-01-07T09:00:00+00:00|2026-01-07T09:00:00Z","2026-01-12T09:00:00+00:00|2026-01-12T09:00:00Z","2026-01-14T09:00:00+00:00|2026-01-14T09:00:00Z"],"type":"occurrences"}`
- `sha256:c3e59ccf2a26c0c467a899e8c2898a861dd3ba88856c2e1c297432418f417923`: 1 build(s): go.rrule-go. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-07T09:00:00-05:00|2026-01-07T14:00:00Z","2026-01-14T09:00:00-05:00|2026-01-14T14:00:00Z"],"type":"occurrences"}`

### `RRULE-SET-011` — `documented dialect difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `rrule.profile`, `rrule.rdate_period`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 4 build(s): go.rrule-go, javascript.rrule-js, python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:7007ec2ab690ff5c7bb5fcd54e1309b2cf36638e52fe5707b0cb0f9ed1b8dee9`: 1 build(s): php.php-rrule. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-12T09:00:00-05:00|2026-01-12T14:00:00Z"],"type":"occurrences"}`

### `RRULE-SET-012` — `standard ambiguity`

Classification: `AMBIGUOUS_STANDARD`. Registered axes: `rrule.rdate_before_dtstart`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: conformant_admissible=2. Matched cases: reject. Answer: `{"type":"rejection"}`
- `sha256:2b3634bf1a5e2d59c44f1f950bfc69fc2044e733cd2195c09c61247d27734320`: 3 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule. Verdicts: conformant_admissible=3. Matched cases: include. Answer: `{"occurrences":["2025-12-29T09:00:00-05:00|2025-12-29T14:00:00Z","2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-12T09:00:00-05:00|2026-01-12T14:00:00Z"],"type":"occurrences"}`

### `RRULE-SET-014` — `normative violation`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:61581df7a748f6daf2cfcd8db35a71224dfd5a849f9d03eedb600f806cbbd148`: 2 build(s): go.rrule-go, php.php-rrule. Verdicts: conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-06T09:00:00-05:00|2026-01-06T14:00:00Z","2026-01-06T09:00:01-05:00|2026-01-06T14:00:01Z","2026-01-07T09:00:00-05:00|2026-01-07T14:00:00Z"],"type":"occurrences"}`
- `sha256:811186756156eca1e92e4b7e8ffb7b42404c47114ddf057ccdbe62fafc55b067`: 1 build(s): javascript.rrule-js. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-01-06T09:00:01-05:00|2026-01-06T14:00:01Z","2026-01-05T09:00:00-05:00|2026-01-05T14:00:00Z","2026-01-06T09:00:00-05:00|2026-01-06T14:00:00Z","2026-01-07T09:00:00-05:00|2026-01-07T14:00:00Z"],"type":"occurrences"}`

### `TZDB-001` — `tzdb provenance difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `tz.tzdb_version`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:8c8a8a559757807d76756913d72076d7d72affc4d9e9cd0234098d3a37b944c2`: 9 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.croniter.system, python.croniterAnd.system, python.cronsim.system. Verdicts: non_conformant=9. Matched cases: none. Answer: `{"occurrences":["2026-10-30T12:00:00-07:00|2026-10-30T19:00:00Z","2026-10-31T12:00:00-07:00|2026-10-31T19:00:00Z","2026-11-01T12:00:00-08:00|2026-11-01T20:00:00Z","2026-11-02T12:00:00-08:00|2026-11-02T20:00:00Z"],"type":"occurrences"}`
- `sha256:99fc94fa52ae066e8625c4fc0a9d57c42521c1a717ca673ed1309eb35a8ba84c`: 4 build(s): python.aps.vendored, python.croniter.vendored, python.croniterAnd.vendored, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-10-30T12:00:00-07:00|2026-10-30T19:00:00Z","2026-10-31T12:00:00-07:00|2026-10-31T19:00:00Z","2026-11-01T12:00:00-07:00|2026-11-01T19:00:00Z","2026-11-02T12:00:00-07:00|2026-11-02T19:00:00Z"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`

### `TZDB-002` — `tzdb provenance difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `tz.tzdb_version`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:3a122a3b5d5296e119fa3b3d45c723446d35f2be3ea606110f8923a2cba0a3b8`: 4 build(s): python.aps.vendored, python.croniter.vendored, python.croniterAnd.vendored, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-10-30T12:00:00-06:00|2026-10-30T18:00:00Z","2026-10-31T12:00:00-06:00|2026-10-31T18:00:00Z","2026-11-01T12:00:00-06:00|2026-11-01T18:00:00Z","2026-11-02T12:00:00-06:00|2026-11-02T18:00:00Z"],"type":"occurrences"}`
- `sha256:4481fb0ae4a4c0c1a3623617aea1f29d190feda17ed057d5aa1e6970954d5988`: 9 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.croniter.system, python.croniterAnd.system, python.cronsim.system. Verdicts: non_conformant=9. Matched cases: none. Answer: `{"occurrences":["2026-10-30T12:00:00-06:00|2026-10-30T18:00:00Z","2026-10-31T12:00:00-06:00|2026-10-31T18:00:00Z","2026-11-01T12:00:00-07:00|2026-11-01T19:00:00Z","2026-11-02T12:00:00-07:00|2026-11-02T19:00:00Z"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`

### `TZDB-003` — `tzdb provenance difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `tz.tzdb_version`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:4e1ce7dd588c045ee459aebee3c9ff428c37676df10a053ab2b1bb5a32308f9b`: 9 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.croniter.system, python.croniterAnd.system, python.cronsim.system. Verdicts: non_conformant=9. Matched cases: none. Answer: `{"occurrences":["2026-09-18T12:00:00+01:00|2026-09-18T11:00:00Z","2026-09-19T12:00:00+01:00|2026-09-19T11:00:00Z","2026-09-20T12:00:00+01:00|2026-09-20T11:00:00Z","2026-09-21T12:00:00+01:00|2026-09-21T11:00:00Z"],"type":"occurrences"}`
- `sha256:7b1cfc025cae8fd64ac212af5aa313d8bfe359146258d687b3bfc4655ddb027f`: 4 build(s): python.aps.vendored, python.croniter.vendored, python.croniterAnd.vendored, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-09-18T12:00:00+01:00|2026-09-18T11:00:00Z","2026-09-19T12:00:00+01:00|2026-09-19T11:00:00Z","2026-09-20T12:00:00+00:00|2026-09-20T12:00:00Z","2026-09-21T12:00:00+00:00|2026-09-21T12:00:00Z"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`

### `TZDB-004` — `tzdb provenance difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `tz.tzdb_version`.

- `sha256:1ac6b40d45e0389c703b723ef65748e28ccc0adc713d6eef3a417afee75802c8`: 2 build(s): python.dateutil.system, python.dateutil.vendored. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"occurrences":["2026-10-18T12:00:00+00:00|2026-10-18T12:00:00Z","2026-10-25T12:00:00+00:00|2026-10-25T12:00:00Z","2026-11-01T12:00:00+00:00|2026-11-01T12:00:00Z","2026-11-08T12:00:00+00:00|2026-11-08T12:00:00Z"],"type":"occurrences"}`
- `sha256:90c6e24b03d0d9d2f042d9a28199248bfcb9cf85b83f0377b29684d0eff4b494`: 4 build(s): go.rrule-go, javascript.rrule-js, php.php-rrule, python.pandas.system. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2026-10-18T12:00:00-07:00|2026-10-18T19:00:00Z","2026-10-25T12:00:00-07:00|2026-10-25T19:00:00Z","2026-11-01T12:00:00-08:00|2026-11-01T20:00:00Z","2026-11-08T12:00:00-08:00|2026-11-08T20:00:00Z"],"type":"occurrences"}`
- `sha256:f61a13a14bd50450bd57465bda2a553c836189892bd5b2c62c8f6671e3c625b6`: 1 build(s): python.pandas.vendored. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2026-10-18T12:00:00-07:00|2026-10-18T19:00:00Z","2026-10-25T12:00:00-07:00|2026-10-25T19:00:00Z","2026-11-01T12:00:00-07:00|2026-11-01T19:00:00Z","2026-11-08T12:00:00-07:00|2026-11-08T19:00:00Z"],"type":"occurrences"}`

### `TZDB-005` — `tzdb provenance difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `cron.dst_gap`, `tz.tzdb_version`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:1788cfe42c6c43e3ad9f89d6dd5301b627d2720d00330a85c92cca0f84d4c267`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 02:30 AM"],"type":"occurrences"}`
- `sha256:1eb48406f9a42f4fd7254d16a538ae6f8bdf41d10f0eb889ec36f19bd2f63ad7`: 4 build(s): javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2027-03-12T02:30:00-08:00|2027-03-12T10:30:00Z","2027-03-13T02:30:00-08:00|2027-03-13T10:30:00Z","2027-03-14T03:30:00-07:00|2027-03-14T10:30:00Z","2027-03-15T02:30:00-07:00|2027-03-15T09:30:00Z"],"type":"occurrences"}`
- `sha256:475f4a48f128d0e9a2e52bcf5afce295b7b44494aaa02a86ad6c142675181ca6`: 1 build(s): python.aps.system. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2027-03-12T02:30:00-08:00|2027-03-12T10:30:00Z","2027-03-13T02:30:00-08:00|2027-03-13T10:30:00Z","2027-03-14T02:30:00-08:00|2027-03-14T10:30:00Z","2027-03-15T02:30:00-07:00|2027-03-15T09:30:00Z"],"type":"occurrences"}`
- `sha256:9a87ee1baf9783e56373586bd6e24bf3a17ea595bda96df3f40873a643e0b62c`: 1 build(s): go.robfig-cron. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["2027-03-12T02:30:00-08:00|2027-03-12T10:30:00Z","2027-03-13T02:30:00-08:00|2027-03-13T10:30:00Z","2027-03-15T02:30:00-07:00|2027-03-15T09:30:00Z","2027-03-16T02:30:00-07:00|2027-03-16T09:30:00Z"],"type":"occurrences"}`
- `sha256:bda6c6042a4d7353159e73b068f430b261b934ed9fd3fc5d0e9f775b85cf5cf1`: 4 build(s): python.aps.vendored, python.croniter.vendored, python.croniterAnd.vendored, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2027-03-12T02:30:00-07:00|2027-03-12T09:30:00Z","2027-03-13T02:30:00-07:00|2027-03-13T09:30:00Z","2027-03-14T02:30:00-07:00|2027-03-14T09:30:00Z","2027-03-15T02:30:00-07:00|2027-03-15T09:30:00Z"],"type":"occurrences"}`
- `sha256:f69e05a4d41f2c17fd00513b138781d12eedae49c715a011b8811f5a04f6ba23`: 3 build(s): python.croniter.system, python.croniterAnd.system, python.cronsim.system. Verdicts: non_conformant=3. Matched cases: none. Answer: `{"occurrences":["2027-03-12T02:30:00-08:00|2027-03-12T10:30:00Z","2027-03-13T02:30:00-08:00|2027-03-13T10:30:00Z","2027-03-14T03:00:00-07:00|2027-03-14T10:00:00Z","2027-03-15T02:30:00-07:00|2027-03-15T09:30:00Z"],"type":"occurrences"}`

### `TZDB-006` — `tzdb provenance difference`

Classification: `POLICY_DEPENDENT`. Registered axes: `tz.tzdb_version`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:3bf197d729f2187b6bead32f8c038a57d59d50c22de857563c25ace6012c71d0`: 4 build(s): python.aps.vendored, python.croniter.vendored, python.croniterAnd.vendored, python.cronsim.vendored. Verdicts: non_conformant=4. Matched cases: none. Answer: `{"occurrences":["2027-01-14T12:00:00-06:00|2027-01-14T18:00:00Z","2027-01-15T12:00:00-06:00|2027-01-15T18:00:00Z"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`
- `sha256:dd608c67758cc30d0e82ce8c7af184f159ad22482bd0e0c660bbaf054b08823b`: 9 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.croniter.system, python.croniterAnd.system, python.cronsim.system. Verdicts: non_conformant=9. Matched cases: none. Answer: `{"occurrences":["2027-01-14T12:00:00-07:00|2027-01-14T19:00:00Z","2027-01-15T12:00:00-07:00|2027-01-15T19:00:00Z"],"type":"occurrences"}`

### `TZDB-007` — `tzdb provenance difference`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:67758c5d2b7ca50cc6d9b9a66ec90c4d315c03a4e3dcc0bfbcf10c34b319b7cf`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=13. Matched cases: none. Answer: `{"occurrences":["1992-09-25T12:00:00+01:00|1992-09-25T11:00:00Z","1992-09-26T12:00:00+01:00|1992-09-26T11:00:00Z","1992-09-27T12:00:00+01:00|1992-09-27T11:00:00Z","1992-09-28T12:00:00+01:00|1992-09-28T11:00:00Z"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`

### `TZDB-008` — `tzdb provenance difference`

Classification: `INVALID`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 14 build(s): go.robfig-cron, go.robfig-cron-seconds, javascript.cron-parser, javascript.cron-parser-strict, javascript.croner, javascript.croner-legacyMode-false, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant_admissible=14. Matched cases: reject. Answer: `{"type":"rejection"}`
- `sha256:a88c983fb5bf1ea69ea02a8ea73e55c6ae5d00e5945c18d36befd11d1d3de546`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"type":"accepted"}`

### `TZDB-009` — `tzdb provenance difference`

Classification: `DIALECT_DEPENDENT`. Registered axes: `tz.database_profile`, `tz.link_handling`.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`
- `sha256:d332075cbb8b0570cdc0ccd94d3b7f6abf452762702b81ab9745ae1a3a7e1ad9`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: non_conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-01-14T12:00:00-08:00|2026-01-14T20:00:00Z","2026-01-15T12:00:00-08:00|2026-01-15T20:00:00Z"],"type":"occurrences"}`

### `TZDB-010` — `tzdb provenance difference`

Classification: `NORMATIVE`. Registered axes: none.

- `sha256:031c014f6a8e0ad4eff2513925fb7cf9b7db12dd3520bf8154766ebdc31d1279`: 2 build(s): go.robfig-cron-seconds, javascript.cron-parser-strict. Verdicts: non_conformant=2. Matched cases: none. Answer: `{"type":"rejection"}`
- `sha256:08cda5078654416185789198637ac7d94332d2c7fb07da463002c64a2c7a4bf5`: 13 build(s): go.robfig-cron, javascript.cron-parser, javascript.croner, javascript.croner-legacyMode-false, php.php-cron-expression, python.aps.system, python.aps.vendored, python.croniter.system, python.croniter.vendored, python.croniterAnd.system, python.croniterAnd.vendored, python.cronsim.system, python.cronsim.vendored. Verdicts: conformant=13. Matched cases: none. Answer: `{"occurrences":["2026-01-14T12:00:00-05:00|2026-01-14T17:00:00Z","2026-01-15T12:00:00-05:00|2026-01-15T17:00:00Z"],"type":"occurrences"}`
- `sha256:c702ad5e59fc95e07e22934c8bf9054ab8df73b2db335a227e3e5c3723d5b61b`: 1 build(s): javascript.cronstrue. Verdicts: non_conformant=1. Matched cases: none. Answer: `{"occurrences":["DESCRIPTION:At 12:00 PM"],"type":"occurrences"}`

